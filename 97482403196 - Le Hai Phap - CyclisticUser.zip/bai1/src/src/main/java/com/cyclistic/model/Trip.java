// src/main/java/com/cyclistic/model/Trip.java
package com.cyclistic.model;

import java.time.LocalDateTime;

public class Trip {
    private String rideId;
    private String rideableType;
    private LocalDateTime startedAt; // Sẽ được đọc từ CSDL (cột started_at hoặc start_datetime)
    private LocalDateTime endedAt;   // Sẽ được đọc từ CSDL (cột ended_at hoặc end_datetime)
    private String startStationName;
    private String startStationId;
    private String endStationName;
    private String endStationId;
    private double startLat;
    private double startLng;
    private double endLat;
    private double endLng;
    private String memberCasual;
    private int durationMinutes; // Sẽ được tính toán và set bởi DAO

    public Trip() {}

    // Getters and Setters cho tất cả các trường (đầy đủ)
    public String getRideId() { return rideId; }
    public void setRideId(String rideId) { this.rideId = rideId; }
    public String getRideableType() { return rideableType; }
    public void setRideableType(String rideableType) { this.rideableType = rideableType; }
    public LocalDateTime getStartedAt() { return startedAt; }
    public void setStartedAt(LocalDateTime startedAt) { this.startedAt = startedAt; }
    public LocalDateTime getEndedAt() { return endedAt; }
    public void setEndedAt(LocalDateTime endedAt) { this.endedAt = endedAt; }
    public String getStartStationName() { return startStationName; }
    public void setStartStationName(String startStationName) { this.startStationName = startStationName; }
    public String getStartStationId() { return startStationId; }
    public void setStartStationId(String startStationId) { this.startStationId = startStationId; }
    public String getEndStationName() { return endStationName; }
    public void setEndStationName(String endStationName) { this.endStationName = endStationName; }
    public String getEndStationId() { return endStationId; }
    public void setEndStationId(String endStationId) { this.endStationId = endStationId; }
    public double getStartLat() { return startLat; }
    public void setStartLat(double startLat) { this.startLat = startLat; }
    public double getStartLng() { return startLng; }
    public void setStartLng(double startLng) { this.startLng = startLng; }
    public double getEndLat() { return endLat; }
    public void setEndLat(double endLat) { this.endLat = endLat; }
    public double getEndLng() { return endLng; }
    public void setEndLng(double endLng) { this.endLng = endLng; }
    public String getMemberCasual() { return memberCasual; }
    public void setMemberCasual(String memberCasual) { this.memberCasual = memberCasual; }
    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }
}