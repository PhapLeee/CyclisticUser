// src/main/java/com/cyclistic/ui/controller/TripManagementController.java
package com.cyclistic.ui.controller;

import com.cyclistic.model.Trip;
import com.cyclistic.service.TripService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import com.cyclistic.ui.controller.CellFactoryUtils;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TripManagementController {

    @FXML private TableView<Trip> tripTableView;
    @FXML private TableColumn<Trip, String> rideIdColumn;
    @FXML private TableColumn<Trip, String> rideableTypeColumn;
    @FXML private TableColumn<Trip, LocalDateTime> startedAtColumn; // Kiểu LocalDateTime cho phép sắp xếp tự nhiên
    @FXML private TableColumn<Trip, LocalDateTime> endedAtColumn;   // Kiểu LocalDateTime
    @FXML private TableColumn<Trip, String> startStationNameColumn;
    @FXML private TableColumn<Trip, String> endStationNameColumn;
    @FXML private TableColumn<Trip, String> memberCasualColumn;
    @FXML private TableColumn<Trip, Integer> durationMinutesColumn;

    @FXML private TextField searchField;
    @FXML private Button searchButton; // Không cần thiết nếu searchField xử lý Enter
    @FXML private Button clearSearchButton;
    @FXML private Button refreshButton; // Đã có sẵn trong FXML

    @FXML private Button prevButton;
    @FXML private Button nextButton;
    @FXML private Label pageInfoLabel;

    private TripService tripService;
    private final ObservableList<Trip> tripData = FXCollections.observableArrayList();
    private int currentPage = 1;
    private final int PAGE_SIZE = 50; // Số lượng trip mỗi trang, có thể làm thành cấu hình
    private String currentSearchKeyword = "";

    @FXML
    private void initialize() {
        try {
            tripService = new TripService();
            System.out.println("[TripManagementController] TripService initialized.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Service Error", "Could not initialize Trip Service: " + e.getMessage());
            if (tripTableView != null) { // Kiểm tra null trước khi sử dụng
                tripTableView.setPlaceholder(new Label("Error: Trip Service unavailable."));
            }
            disableControlsOnError();
            return;
        }

        configureTableColumns();
        configureSearchField();
        configureRowFactoryForDetails(); // Thêm xem chi tiết khi double click

        tripTableView.setItems(tripData);
        tripTableView.setPlaceholder(new Label("Loading trip data..."));

        loadTripData(); // Tải trang đầu tiên
    }

    private void configureTableColumns() {
        rideIdColumn.setCellValueFactory(new PropertyValueFactory<>("rideId"));
        rideableTypeColumn.setCellValueFactory(new PropertyValueFactory<>("rideableType"));

        // Định dạng hiển thị cho cột LocalDateTime, nhưng vẫn giữ kiểu LocalDateTime cho TableColumn để sắp xếp
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        startedAtColumn.setCellValueFactory(new PropertyValueFactory<>("startedAt"));
        startedAtColumn.setCellFactory(CellFactoryUtils.createFormattedLocalDateTimeCell(formatter));

        endedAtColumn.setCellValueFactory(new PropertyValueFactory<>("endedAt"));
        endedAtColumn.setCellFactory(CellFactoryUtils.createFormattedLocalDateTimeCell(formatter));

        startStationNameColumn.setCellValueFactory(new PropertyValueFactory<>("startStationName"));
        endStationNameColumn.setCellValueFactory(new PropertyValueFactory<>("endStationName"));
        memberCasualColumn.setCellValueFactory(new PropertyValueFactory<>("memberCasual"));
        durationMinutesColumn.setCellValueFactory(new PropertyValueFactory<>("durationMinutes"));
        // Xử lý hiển thị "N/A" cho duration nếu cần, tương tự như startedAt/endedAt
        durationMinutesColumn.setCellFactory(CellFactoryUtils.createDurationCell());

    }
    private void configureSearchField() {
        searchField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                handleSearch();
            }
        });
    }
    private void configureRowFactoryForDetails() {
        tripTableView.setRowFactory(tv -> {
            TableRow<Trip> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 2) {
                    Trip clickedTrip = row.getItem();
                    showTripDetailsDialog(clickedTrip);
                }
            });
            return row;
        });
    }


    private void loadTripData() {
        if (tripService == null) {
            showAlert(Alert.AlertType.WARNING, "Service Unavailable", "Trip service is not initialized.");
            tripTableView.setPlaceholder(new Label("Trip Service is unavailable."));
            disableControlsOnError();
            return;
        }
        try {
            tripData.clear(); // Xóa dữ liệu cũ trên TableView
            System.out.println("[TripManagementController] Requesting trips. Page: " + currentPage + ", Keyword: '" + currentSearchKeyword + "'");

            List<Trip> trips;
            if (currentSearchKeyword.isEmpty()) {
                trips = tripService.getAllTrips(currentPage, PAGE_SIZE);
            } else {
                trips = tripService.searchTrips(currentSearchKeyword, currentPage, PAGE_SIZE);
            }

            if (trips != null && !trips.isEmpty()) {
                tripData.addAll(trips);
                System.out.println("[TripManagementController] Displayed " + tripData.size() + " trips.");
                tripTableView.setPlaceholder(null); // Xóa placeholder nếu có dữ liệu
            } else {
                System.out.println("[TripManagementController] No trips found for current criteria.");
                if (currentSearchKeyword.isEmpty() && currentPage == 1) {
                    tripTableView.setPlaceholder(new Label("No trip data available in the database."));
                } else {
                    tripTableView.setPlaceholder(new Label("No trips found matching your criteria."));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Load Error", "Failed to load trip data: " + e.getMessage());
            tripTableView.setPlaceholder(new Label("Error loading trip data. Please try again."));
        }
        // TableView tự cập nhật. Gọi refresh() nếu có vấn đề về render.
        // tripTableView.refresh();
        updatePaginationControls();
    }

    @FXML
    private void handleRefreshData() {
        searchField.setText(""); // Xóa trường tìm kiếm
        currentSearchKeyword = "";
        currentPage = 1; // Reset về trang đầu khi refresh
        loadTripData();
        if (tripService != null) { // Chỉ hiển thị nếu service hoạt động
            // showAlert(Alert.AlertType.INFORMATION, "Data Refreshed", "Trip data has been reloaded.");
            System.out.println("[TripManagementController] Data refreshed.");
        }
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText().trim();
        // Chỉ thực hiện tìm kiếm nếu từ khóa thay đổi hoặc từ khóa rỗng (để xóa tìm kiếm)
        if (!keyword.equals(currentSearchKeyword) || (keyword.isEmpty() && !currentSearchKeyword.isEmpty())) {
            currentSearchKeyword = keyword;
            currentPage = 1; // Luôn reset về trang 1 khi tìm kiếm mới
            loadTripData();
        } else if (keyword.equals(currentSearchKeyword) && !keyword.isEmpty()) {
            // Nếu từ khóa giống hệt và không rỗng, có thể không cần làm gì hoặc chỉ refresh trang hiện tại
            System.out.println("[TripManagementController] Search keyword unchanged, reloading current page.");
            loadTripData();
        }
    }


    @FXML
    private void handleClearSearch() {
        if (!currentSearchKeyword.isEmpty() || !searchField.getText().isEmpty()) {
            searchField.setText("");
            currentSearchKeyword = "";
            currentPage = 1;
            loadTripData();
        }
    }


    @FXML
    private void handlePreviousPage() {
        if (currentPage > 1) {
            currentPage--;
            loadTripData();
        }
    }

    @FXML
    private void handleNextPage() {
        int totalItems;
        if (currentSearchKeyword.isEmpty()) {
            totalItems = tripService.getTotalTripCount();
        } else {
            totalItems = tripService.getTotalSearchTripCount(currentSearchKeyword);
        }
        int totalPages = (int) Math.ceil((double) totalItems / PAGE_SIZE);
        if (totalPages == 0) totalPages = 1; // Đảm bảo ít nhất 1 trang

        if (currentPage < totalPages) {
            currentPage++;
            loadTripData();
        }
    }

    private void updatePaginationControls() {
        if (tripService == null) {
            disableControlsOnError();
            return;
        }
        int totalItems;
        if (currentSearchKeyword.isEmpty()) {
            totalItems = tripService.getTotalTripCount();
        } else {
            totalItems = tripService.getTotalSearchTripCount(currentSearchKeyword);
        }
        int totalPages = (int) Math.ceil((double) totalItems / PAGE_SIZE);
        if (totalPages == 0) totalPages = 1;

        if (pageInfoLabel != null) pageInfoLabel.setText("Page " + currentPage + " of " + totalPages + " (Total: " + totalItems + ")");
        if (prevButton != null) prevButton.setDisable(currentPage <= 1);
        if (nextButton != null) nextButton.setDisable(currentPage >= totalPages);
    }
    private void disableControlsOnError() {
        if (pageInfoLabel != null) pageInfoLabel.setText("Page N/A (Error)");
        if (prevButton != null) prevButton.setDisable(true);
        if (nextButton != null) nextButton.setDisable(true);
        if (searchField != null) searchField.setDisable(true);
        if (searchButton != null) searchButton.setDisable(true);
        if (clearSearchButton != null) clearSearchButton.setDisable(true);
        if (refreshButton != null) refreshButton.setDisable(true);
    }


    private void showTripDetailsDialog(Trip trip) {
        if (trip == null) return;

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Trip Details");
        alert.setHeaderText("Ride ID: " + trip.getRideId());

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String startedAtStr = trip.getStartedAt() != null ? trip.getStartedAt().format(formatter) : "N/A";
        String endedAtStr = trip.getEndedAt() != null ? trip.getEndedAt().format(formatter) : "N/A";
        String durationStr = (trip.getDurationMinutes() == 0 && (trip.getStartedAt() == null || trip.getEndedAt() == null || !trip.getEndedAt().isAfter(trip.getStartedAt())))
                ? "N/A"
                : String.valueOf(trip.getDurationMinutes());


        String content = String.format(
            "Rideable Type: %s\n" +
            "Started At: %s\n" +
            "Ended At: %s\n" +
            "Start Station: %s (ID: %s)\n" +
            "End Station: %s (ID: %s)\n" +
            "User Type: %s\n" +
            "Duration: %s minutes\n" +
            "Start Lat/Lng: %s / %s\n" +
            "End Lat/Lng: %s / %s",
            getValueOrDefault(trip.getRideableType(), "N/A"),
            startedAtStr,
            endedAtStr,
            getValueOrDefault(trip.getStartStationName(), "N/A"), getValueOrDefault(trip.getStartStationId(), "N/A"),
            getValueOrDefault(trip.getEndStationName(), "N/A"), getValueOrDefault(trip.getEndStationId(), "N/A"),
            getValueOrDefault(trip.getMemberCasual(), "N/A"),
            durationStr,
            trip.getStartLat() != 0.0 ? String.format("%.5f", trip.getStartLat()) : "N/A", // Giả sử 0.0 là không có dữ liệu
            trip.getStartLng() != 0.0 ? String.format("%.5f", trip.getStartLng()) : "N/A",
            trip.getEndLat() != 0.0 ? String.format("%.5f", trip.getEndLat()) : "N/A",
            trip.getEndLng() != 0.0 ? String.format("%.5f", trip.getEndLng()) : "N/A"
        );
        alert.setContentText(content);
        // Đảm bảo dialog có owner để hiển thị đúng vị trí (nếu cần)
        // if (tripTableView != null && tripTableView.getScene() != null && tripTableView.getScene().getWindow() != null) {
        //     alert.initOwner(tripTableView.getScene().getWindow());
        // }
        alert.showAndWait();
    }

    private String getValueOrDefault(String value, String defaultValue) {
        return (value == null || value.trim().isEmpty()) ? defaultValue : value;
    }


    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null); // Hoặc một header ngắn gọn
        alert.setContentText(message);
        // alert.initOwner(tripTableView.getScene().getWindow()); // Cân nhắc nếu cần
        alert.showAndWait();
    }
}