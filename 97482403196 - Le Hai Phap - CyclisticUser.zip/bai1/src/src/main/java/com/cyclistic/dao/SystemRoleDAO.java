// src/main/java/com/ccyclistic/dao/SystemRoleDAO.java
package com.cyclistic.dao;

import com.cyclistic.model.SystemRole;
import com.cyclistic.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SystemRoleDAO {

    public SystemRole findById(int id) {
        String sql = "SELECT * FROM system_roles WHERE id = ?";
        SystemRole role = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                role = new SystemRole();
                role.setId(rs.getInt("id"));
                role.setRoleName(rs.getString("role_name"));
            }
        } catch (SQLException e) {
            System.err.println("Error finding role by id: " + e.getMessage());
            e.printStackTrace();
        }
        return role;
    }

    public SystemRole findByName(String roleName) {
        String sql = "SELECT * FROM system_roles WHERE role_name = ?";
        SystemRole role = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, roleName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                role = new SystemRole();
                role.setId(rs.getInt("id"));
                role.setRoleName(rs.getString("role_name"));
            }
        } catch (SQLException e) {
            System.err.println("Error finding role by name: " + e.getMessage());
            e.printStackTrace();
        }
        return role;
    }

    public List<SystemRole> getAllRoles() {
        List<SystemRole> roles = new ArrayList<>();
        String sql = "SELECT * FROM system_roles ORDER BY role_name";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                SystemRole role = new SystemRole();
                role.setId(rs.getInt("id"));
                role.setRoleName(rs.getString("role_name"));
                roles.add(role);
            }
        } catch (SQLException e) {
            System.err.println("Error getting all roles: " + e.getMessage());
            e.printStackTrace();
        }
        return roles;
    }

    public boolean addRole(SystemRole role) {
        String sql = "INSERT INTO system_roles (role_name) VALUES (?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, role.getRoleName());
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        role.setId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding role: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    // TODO: Thêm updateRole, deleteRole nếu cần
}