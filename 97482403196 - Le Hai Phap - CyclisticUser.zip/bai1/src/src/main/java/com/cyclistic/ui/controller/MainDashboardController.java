// src/main/java/com/cyclistic/ui/controller/MainDashboardController.java
// Gói này có thể là com.ccyclistic.ui.controller nếu bạn di chuyển các controller vào đó
// Tuy nhiên, dựa trên file OCR, controller của bạn đang ở com.cyclistic.ui.controller
package com.cyclistic.ui.controller;

import com.ccyclistic.MainApp; // Giả sử MainApp ở com.ccyclistic
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.Objects;

public class MainDashboardController {

    @FXML private StackPane contentArea;
    @FXML private Label statusBarLabel;
    @FXML private VBox navigationVBox;

    private Node currentViewNode;

    @FXML
    private void initialize() {
        showDashboardOverview(); // Hiển thị view mặc định khi dashboard mở
        updateStatusBar("Welcome to Cyclistic Data Importer - Pháp Sư Edition!");
    }

    private void loadView(String fxmlPath, String viewName) {
        try {
            if (currentViewNode != null) {
                contentArea.getChildren().remove(currentViewNode);
            }

            System.out.println("[MainDashboardController] Attempting to load FXML: " + fxmlPath);
            java.net.URL resourceUrl = getClass().getResource(fxmlPath);

            if (resourceUrl == null) {
                System.err.println("[MainDashboardController] FATAL: Resource not found for FXML path: " + fxmlPath);
                showErrorDialog("Load Error", "Could not find the FXML file: " + fxmlPath.substring(fxmlPath.lastIndexOf('/') + 1) + "\nPlease check the path: " + fxmlPath);
                // Hiển thị một label lỗi trong contentArea
                Label errorLabel = new Label("Error: Could not load " + viewName + ". FXML file not found at " + fxmlPath);
                errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 16px;");
                contentArea.getChildren().add(errorLabel);
                currentViewNode = errorLabel;
                return;
            }

            FXMLLoader loader = new FXMLLoader(resourceUrl);
            Parent view = loader.load();
            currentViewNode = view;
            contentArea.getChildren().add(view);
            updateStatusBar(viewName + " view loaded.");
            highlightNavigationButton(viewName);
        } catch (IOException e) {
            System.err.println("[MainDashboardController] IOException while loading FXML: " + fxmlPath);
            e.printStackTrace();
            updateStatusBar("Error loading " + viewName + " view: " + e.getMessage());
            showErrorDialog("Load Error", "Could not load the " + viewName + " view: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("[MainDashboardController] Unexpected error while loading FXML: " + fxmlPath);
            e.printStackTrace();
            showErrorDialog("Load Error", "An unexpected error occurred while loading: " + viewName + "\n" + e.getMessage());
        }
    }

    private void highlightNavigationButton(String viewName) {
        if (navigationVBox == null || navigationVBox.getChildren() == null) return;
        navigationVBox.getChildren().forEach(node -> {
            if (node instanceof javafx.scene.control.Button) {
                javafx.scene.control.Button button = (javafx.scene.control.Button) node;
                // Cố gắng khớp chính xác hơn dựa trên text của button hoặc userData
                String buttonText = button.getText().toLowerCase();
                String simplifiedViewName = viewName.toLowerCase().split(" ")[0]; // Lấy từ đầu tiên của viewName

                if (buttonText.contains(simplifiedViewName) ||
                    (buttonText.contains("dashboard") && simplifiedViewName.contains("dashboard")) ||
                    (buttonText.contains("station") && simplifiedViewName.contains("station")) ||
                    (buttonText.contains("trip") && simplifiedViewName.contains("trip")) ||
                    (buttonText.contains("report") && simplifiedViewName.contains("report")) ) {
                    button.requestFocus();
                }
            }
        });
    }

    @FXML
    private void showDashboardOverview() {
        // Xóa view cũ trước khi thêm view mới
        if (currentViewNode != null) {
            contentArea.getChildren().remove(currentViewNode);
        }
        Label overviewLabel = new Label("Main Dashboard Overview - Thống kê nhanh ở đây!");
        overviewLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #E0E0E0;"); // Sử dụng màu từ CSS nếu có
        contentArea.getChildren().add(overviewLabel);
        currentViewNode = overviewLabel; // Cập nhật currentViewNode
        updateStatusBar("Dashboard Overview loaded.");
        highlightNavigationButton("Dashboard");
    }

    @FXML
    private void showStationManagement() {
        // SỬA ĐƯỜNG DẪN Ở ĐÂY - Đảm bảo khớp với cấu trúc src/main/resources
        // và tên thư mục FXML viết hoa
        loadView("/com/ccyclistic/ui/FXML/StationManagementPanel.fxml", "Station Management");
    }

    @FXML
    private void showTripManagement() {
        // SỬA ĐƯỜNG DẪN Ở ĐÂY
        loadView("/com/ccyclistic/ui/FXML/TripManagementPanel.fxml", "Trip Management");
    }

    @FXML
    private void showReports() {
        // SỬA ĐƯỜNG DẪN Ở ĐÂY
        loadView("/com/ccyclistic/ui/FXML/ReportPanel.fxml", "Reports & Charts");
    }

    // @FXML
    // private void showUserManagement() {
    //     loadView("/com/ccyclistic/ui/FXML/UserManagementPanel.fxml", "User Management");
    // }

    @FXML
    private void handleImportData() {
        updateStatusBar("Import Data action triggered.");
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Data Import functionality to be implemented!");
        alert.setHeaderText("Import Data");
        alert.showAndWait();
    }

    @FXML
    private void handleSettings() {
        updateStatusBar("Settings action triggered.");
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Settings panel to be implemented!");
        alert.setHeaderText("Application Settings");
        alert.showAndWait();
    }

    @FXML
    private void handleLogout() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to logout?", ButtonType.YES, ButtonType.NO);
        alert.setHeaderText("Logout");
        alert.initOwner(MainApp.getInstance().getPrimaryStage()); // Đặt owner cho dialog
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                updateStatusBar("Logging out...");
                // AppSession.getInstance().clearSession(); // Nếu có AppSession
                MainApp.getInstance().showLoginScreen();
            }
        });
    }

    @FXML
    private void handleExit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to exit?", ButtonType.YES, ButtonType.NO);
        alert.setHeaderText("Exit Application");
        alert.initOwner(MainApp.getInstance().getPrimaryStage()); // Đặt owner cho dialog
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                Platform.exit();
            }
        });
    }

    @FXML
    private void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About Cyclistic Data Importer");
        alert.setHeaderText("Cyclistic Data Importer - Pháp Sư Edition v1.0");
        alert.setContentText("Developed by Pháp Lê\nUsing JavaFX for a powerful UI experience.\n\n\"Mạnh mẽ như Pháp sư Trung Hoa!\"");
        alert.initOwner(MainApp.getInstance().getPrimaryStage()); // Đặt owner cho dialog
        alert.showAndWait();
    }

    private void updateStatusBar(String message) {
        if (statusBarLabel != null) {
            statusBarLabel.setText(message);
        }
    }

    private void showErrorDialog(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        if (MainApp.getInstance() != null && MainApp.getInstance().getPrimaryStage() != null) {
            alert.initOwner(MainApp.getInstance().getPrimaryStage());
        }
        alert.showAndWait();
    }
}