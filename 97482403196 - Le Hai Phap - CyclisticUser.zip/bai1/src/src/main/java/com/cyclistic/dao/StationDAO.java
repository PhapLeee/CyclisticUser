// src/main/java/com/cyclistic/dao/StationDAO.java
package com.cyclistic.dao;

import com.cyclistic.model.Station;
import com.cyclistic.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashSet; // Để giữ thứ tự tương đối và đảm bảo duy nhất
import java.util.List;
import java.util.Set;
import java.util.Comparator; // For sorting

public class StationDAO {

    /**
     * Lấy danh sách các trạm duy nhất từ dữ liệu chuyến đi trong bảng 'all_trip_copy'.
     * Kết hợp cả trạm bắt đầu và trạm kết thúc, đảm bảo duy nhất dựa trên station_id.
     * Các trạm sẽ được sắp xếp theo station_name.
     * @return Danh sách các đối tượng Station duy nhất.
     */
    public List<Station> getAllUniqueStationsFromTrips() {
        // Sử dụng LinkedHashSet để giữ thứ tự chèn (tương đối) và đảm bảo các trạm là duy nhất
        // dựa trên equals() và hashCode() của Station model (nên được override để chỉ dựa vào stationId).
        Set<Station> stationsSet = new LinkedHashSet<>();

        // Câu SQL này lấy tất cả các bản ghi station khả dĩ (start và end)
        // Việc loại bỏ trùng lặp dựa trên station_id sẽ được xử lý trong Java bằng Set.
        String sql = "SELECT station_id, station_name, latitude, longitude FROM (" +
                     "  SELECT start_station_id AS station_id, start_station_name AS station_name, start_lat AS latitude, start_lng AS longitude FROM all_trip_copy WHERE start_station_id IS NOT NULL AND TRIM(start_station_id) <> '' " +
                     "  UNION ALL " + // Sử dụng UNION ALL để lấy tất cả, Java sẽ xử lý việc gộp và loại bỏ trùng lặp ID
                     "  SELECT end_station_id AS station_id, end_station_name AS station_name, end_lat AS latitude, end_lng AS longitude FROM all_trip_copy WHERE end_station_id IS NOT NULL AND TRIM(end_station_id) <> '' " +
                     ") AS all_possible_stations " +
                     "WHERE station_id IS NOT NULL AND TRIM(station_id) <> ''"; // Lọc lại một lần nữa ở query ngoài

        System.out.println("[StationDAO] Executing SQL: " + sql);

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            int count = 0;
            while (rs.next()) {
                String stationId = rs.getString("station_id");
                String stationName = rs.getString("station_name"); // Có thể là null
                double latitude = rs.getDouble("latitude");     // Sẽ là 0.0 nếu NULL trong DB
                double longitude = rs.getDouble("longitude");   // Sẽ là 0.0 nếu NULL trong DB
                int capacity = 0; // Giả sử capacity mặc định là 0 vì không có trong all_trip_copy

                // Đảm bảo stationId không rỗng sau khi đã TRIM
                if (stationId != null && !stationId.trim().isEmpty()) {
                    // Model Station cần có constructor phù hợp
                    // Và equals/hashCode chỉ dựa trên stationId để Set hoạt động đúng
                    stationsSet.add(new Station(stationId.trim(), stationName, latitude, longitude, capacity));
                    count++;
                }
            }
            System.out.println("[StationDAO] Fetched " + count + " raw station records from DB.");
        } catch (SQLException e) {
            System.err.println("Error getting unique stations from trips: " + e.getMessage());
            e.printStackTrace();
            // Trả về danh sách rỗng nếu có lỗi để tránh NullPointerException ở tầng service
            return new ArrayList<>();
        }

        List<Station> uniqueStationsList = new ArrayList<>(stationsSet);

        // Sắp xếp danh sách theo tên trạm (stationName)
        // Xử lý trường hợp stationName có thể là null để tránh NullPointerException khi sort
        uniqueStationsList.sort(Comparator.comparing(
            Station::getStationName,
            Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
        ));

        System.out.println("[StationDAO] Processed into " + uniqueStationsList.size() + " unique stations (sorted by name).");
        return uniqueStationsList;
    }

    // Các phương thức CRUD khác (add, update, delete, findById) không được triển khai
    // vì không có bảng 'stations' riêng biệt.
}