// src/main/java/com/cyclistic/model/Station.java
package com.cyclistic.model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.Objects;

public class Station {
    private final StringProperty stationId;
    private final StringProperty stationName;
    private final DoubleProperty latitude;
    private final DoubleProperty longitude;
    private final IntegerProperty capacity; // Thêm trường capacity

    // Constructors
    public Station() {
        this.stationId = new SimpleStringProperty(null);
        this.stationName = new SimpleStringProperty(null);
        this.latitude = new SimpleDoubleProperty(0.0);
        this.longitude = new SimpleDoubleProperty(0.0);
        this.capacity = new SimpleIntegerProperty(0); // Khởi tạo capacity
    }

    public Station(String stationId, String stationName, double latitude, double longitude, int capacity) {
        this.stationId = new SimpleStringProperty(stationId);
        this.stationName = new SimpleStringProperty(stationName);
        this.latitude = new SimpleDoubleProperty(latitude);
        this.longitude = new SimpleDoubleProperty(longitude);
        this.capacity = new SimpleIntegerProperty(capacity); // Gán giá trị cho capacity
    }

    // JavaFX Property Getters (quan trọng cho TableView binding)
    public StringProperty stationIdProperty() {
        return stationId;
    }

    public StringProperty stationNameProperty() {
        return stationName;
    }

    public DoubleProperty latitudeProperty() {
        return latitude;
    }

    public DoubleProperty longitudeProperty() {
        return longitude;
    }

    public IntegerProperty capacityProperty() { // Property getter cho capacity
        return capacity;
    }

    // Standard Getters (vẫn hữu ích và cần thiết cho PropertyValueFactory nếu không dùng lambda)
    public String getStationId() {
        return stationId.get();
    }

    public String getStationName() {
        return stationName.get();
    }

    public double getLatitude() {
        return latitude.get();
    }

    public double getLongitude() {
        return longitude.get();
    }

    public int getCapacity() { // Getter cho capacity
        return capacity.get();
    }

    // Standard Setters
    public void setStationId(String stationId) {
        this.stationId.set(stationId);
    }

    public void setStationName(String stationName) {
        this.stationName.set(stationName);
    }

    public void setLatitude(double latitude) {
        this.latitude.set(latitude);
    }

    public void setLongitude(double longitude) {
        this.longitude.set(longitude);
    }

    public void setCapacity(int capacity) { // Setter cho capacity
        this.capacity.set(capacity);
    }

    // equals, hashCode, toString (sử dụng .get() để lấy giá trị từ Property)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Station station = (Station) o;
        // So sánh dựa trên giá trị của stationId
        return Objects.equals(getStationId(), station.getStationId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getStationId());
    }

    @Override
    public String toString() {
        String name = getStationName();
        String id = getStationId();
        return (name != null && !name.isEmpty()) ? name : (id != null ? id : "Unknown Station");
    }
}