// src/main/java/com/ccyclistic/model/SystemRole.java
package com.cyclistic.model;

public class SystemRole {
    private int id;
    private String roleName;

    public SystemRole() {}

    public SystemRole(int id, String roleName) {
        this.id = id;
        this.roleName = roleName;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    @Override
    public String toString() {
        return "SystemRole{" +
               "id=" + id +
               ", roleName='" + roleName + '\'' +
               '}';
    }
}