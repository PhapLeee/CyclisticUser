// src/main/java/com/cyclistic/ui/controller/StationManagementController.java
package com.cyclistic.ui.controller;

import com.cyclistic.model.Station;
import com.cyclistic.service.StationService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class StationManagementController {

    @FXML private TableView<Station> stationTableView;
    @FXML private TableColumn<Station, String> idColumn;
    @FXML private TableColumn<Station, String> nameColumn;
    @FXML private TableColumn<Station, Integer> capacityColumn;
    @FXML private TableColumn<Station, Double> latitudeColumn;
    @FXML private TableColumn<Station, Double> longitudeColumn;

    // Các nút này có thể không còn trong FXML hoặc sẽ bị disable/ẩn
    @FXML private Button addButton;    // Sẽ bị ẩn
    @FXML private Button editButton;   // Sẽ bị ẩn
    @FXML private Button deleteButton; // Sẽ bị ẩn
    @FXML private Button refreshButton;

    private StationService stationService;
    private ObservableList<Station> stationData = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        System.out.println("[StationManagementController] Initializing...");
        try {
            // Khởi tạo StationService MỘT LẦN khi controller được tạo.
            // StationService sẽ quản lý việc caching dữ liệu.
            stationService = new StationService();
            System.out.println("[StationManagementController] StationService initialized successfully.");
        } catch (Exception e) {
            System.err.println("[StationManagementController] Error initializing StationService: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Service Error", "Could not initialize Station Service: " + e.getMessage());
            disableUIComponentsOnError();
            return;
        }

        // Cấu hình các cột của TableView
        idColumn.setCellValueFactory(new PropertyValueFactory<>("stationId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("stationName"));
        capacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity")); // Sẽ hiển thị 0 nếu không có dữ liệu
        latitudeColumn.setCellValueFactory(new PropertyValueFactory<>("latitude"));
        longitudeColumn.setCellValueFactory(new PropertyValueFactory<>("longitude"));

        stationTableView.setItems(stationData);
        stationTableView.setPlaceholder(new Label("Loading station data... Click 'Refresh Station List' to load."));

        // Vô hiệu hóa/ẩn các nút không dùng đến (Add, Edit, Delete)
        configureActionButtons();

        // Tải dữ liệu lần đầu khi panel được khởi tạo
        // Việc này sẽ sử dụng cache của StationService nếu có,
        // hoặc kích hoạt việc tải vào cache lần đầu.
        loadStationData();
        System.out.println("[StationManagementController] Initialization complete.");
    }

    private void configureActionButtons() {
        // Ẩn và vô hiệu hóa các nút không dùng đến
        if (addButton != null) {
            addButton.setVisible(false);
            addButton.setManaged(false); // Để nút không chiếm không gian layout
        }
        if (editButton != null) {
            editButton.setVisible(false);
            editButton.setManaged(false);
        }
        if (deleteButton != null) {
            deleteButton.setVisible(false);
            deleteButton.setManaged(false);
        }
    }
    
    private void disableUIComponentsOnError() {
        configureActionButtons(); // Ẩn các nút action
        if(refreshButton != null) refreshButton.setDisable(true); // Vô hiệu hóa cả nút refresh
        stationTableView.setPlaceholder(new Label("Error: Station Service unavailable. Cannot load data."));
    }


    private void loadStationData() {
        if (stationService == null) {
            showAlert(Alert.AlertType.WARNING, "Service Unavailable", "Station service is not initialized. Cannot load data.");
            stationTableView.setPlaceholder(new Label("Station Service is unavailable."));
            return;
        }

        System.out.println("[StationManagementController] Attempting to load station data into TableView...");
        try {
            stationData.clear(); // Xóa dữ liệu cũ trên TableView
            List<Station> stations = stationService.getAllUniqueStationsUsed(); // Lấy dữ liệu từ service (sẽ dùng cache)

            if (stations != null && !stations.isEmpty()) {
                stationData.addAll(stations);
                System.out.println("[StationManagementController] Displayed " + stationData.size() + " unique stations in TableView.");
                stationTableView.setPlaceholder(null); // Xóa placeholder nếu có dữ liệu
            } else {
                System.out.println("[StationManagementController] No unique stations found by service, or service returned empty/null.");
                stationTableView.setPlaceholder(new Label("No stations have been used in any trips yet."));
            }
        } catch (Exception e) {
            System.err.println("[StationManagementController] Error loading station data: " + e.getMessage());
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Load Error", "Failed to load station data: " + e.getMessage());
            stationTableView.setPlaceholder(new Label("Error loading station data. Please try refreshing."));
        }
        // TableView tự cập nhật khi ObservableList (stationData) thay đổi,
        // nhưng gọi refresh() có thể hữu ích trong một số trường hợp phức tạp hơn.
        // stationTableView.refresh();
    }

    @FXML
    private void handleRefreshData() {
        if (stationService != null) {
            System.out.println("[StationManagementController] Refresh button clicked. Requesting station cache refresh from service.");
            stationService.refreshStationsCache(); // Yêu cầu service làm mới cache
            loadStationData(); // Tải lại dữ liệu (giờ sẽ lấy từ DB vì cache đã bị reset/đánh dấu cần tải lại)
            showAlert(Alert.AlertType.INFORMATION, "Data Refreshed", "Station data has been reloaded from the source.");
        } else {
             showAlert(Alert.AlertType.WARNING, "Service Unavailable", "Cannot refresh: Station service is not initialized.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        if (stationTableView != null && stationTableView.getScene() != null && stationTableView.getScene().getWindow() != null) {
            alert.initOwner(stationTableView.getScene().getWindow());
        }
        alert.showAndWait();
    }
}