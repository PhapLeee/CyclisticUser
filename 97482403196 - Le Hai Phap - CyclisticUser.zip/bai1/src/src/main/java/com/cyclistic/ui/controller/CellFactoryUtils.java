// src/main/java/com/cyclistic/ui/controller/CellFactoryUtils.java (hoặc package util)
package com.cyclistic.ui.controller; // Hoặc package util của bạn

import com.cyclistic.model.Trip; // Đảm bảo import đúng model Trip
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CellFactoryUtils {

    public static Callback<TableColumn<Trip, LocalDateTime>, TableCell<Trip, LocalDateTime>> createFormattedLocalDateTimeCell(DateTimeFormatter formatter) {
        return column -> new TableCell<Trip, LocalDateTime>() { // Thêm <Trip, LocalDateTime> cho TableCell
            @Override
            protected void updateItem(LocalDateTime item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setStyle(""); // Reset style
                } else {
                    setText(formatter.format(item));
                    // Bạn có thể thêm style ở đây nếu muốn, ví dụ:
                    // setStyle("-fx-alignment: CENTER-RIGHT;");
                }
            }
        };
    }

    public static Callback<TableColumn<Trip, Integer>, TableCell<Trip, Integer>> createDurationCell() {
        return column -> new TableCell<Trip, Integer>() { // Thêm <Trip, Integer> cho TableCell
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    // Lấy đối tượng Trip của dòng hiện tại một cách an toàn hơn
                    Trip trip = null;
                    if (getTableRow() != null && getTableRow().getItem() != null) {
                         if (getTableRow().getItem() instanceof Trip) { // Kiểm tra kiểu
                            trip = (Trip) getTableRow().getItem();
                        }
                    }

                    if (trip != null && item == 0 &&
                        (trip.getStartedAt() == null || trip.getEndedAt() == null || !trip.getEndedAt().isAfter(trip.getStartedAt()))) {
                        setText("N/A");
                    } else {
                        setText(item.toString());
                    }
                }
            }
        };
    }
}