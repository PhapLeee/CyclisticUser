// src/main/java/com/cyclistic/dao/TripDAO.java
package com.cyclistic.dao;

import com.cyclistic.model.Trip;
import com.cyclistic.util.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class TripDAO {

    // ĐỊNH DẠNG CHUẨN CHO YYYY-MM-DD HH:MM:SS
    private static final DateTimeFormatter DB_DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private Trip mapRowToTrip(ResultSet rs) throws SQLException {
        Trip trip = new Trip();
        String rideIdForDebug = rs.getString("ride_id");
        trip.setRideId(rideIdForDebug);
        trip.setRideableType(rs.getString("rideable_type"));

        LocalDateTime startedAtLocal = null;
        String startDatetimeStr = rs.getString("start_datetime"); // Đọc từ cột VARCHAR 'start_datetime'
        if (startDatetimeStr != null && !startDatetimeStr.trim().isEmpty()) {
            try {
                startedAtLocal = LocalDateTime.parse(startDatetimeStr.trim(), DB_DATETIME_FORMATTER);
                trip.setStartedAt(startedAtLocal);
            } catch (DateTimeParseException e) {
                System.err.println("[TripDAO - mapRowToTrip] Lỗi parse start_datetime: '" + startDatetimeStr + "' cho ride_id: " + rideIdForDebug + ". Lỗi: " + e.getMessage());
            }
        }

        LocalDateTime endedAtLocal = null;
        String endDatetimeStr = rs.getString("end_datetime"); // Đọc từ cột VARCHAR 'end_datetime'
        if (endDatetimeStr != null && !endDatetimeStr.trim().isEmpty()) {
            try {
                endedAtLocal = LocalDateTime.parse(endDatetimeStr.trim(), DB_DATETIME_FORMATTER);
                trip.setEndedAt(endedAtLocal);
            } catch (DateTimeParseException e) {
                System.err.println("[TripDAO - mapRowToTrip] Lỗi parse end_datetime: '" + endDatetimeStr + "' cho ride_id: " + rideIdForDebug + ". Lỗi: " + e.getMessage());
            }
        }

        // ... (phần còn lại của mapRowToTrip giữ nguyên)
        trip.setStartStationName(rs.getString("start_station_name"));
        trip.setStartStationId(rs.getString("start_station_id")); // Giả sử model chấp nhận String
        trip.setEndStationName(rs.getString("end_station_name"));
        trip.setEndStationId(rs.getString("end_station_id"));     // Giả sử model chấp nhận String
        try {
            trip.setStartLat(rs.getDouble("start_lat"));
            trip.setStartLng(rs.getDouble("start_lng"));
            trip.setEndLat(rs.getDouble("end_lat"));
            trip.setEndLng(rs.getDouble("end_lng"));
        } catch (SQLException e) { // Có thể do cột không tồn tại hoặc giá trị không phải double
            // Gán giá trị mặc định hoặc ghi log
            trip.setStartLat(0.0);
            trip.setStartLng(0.0);
            trip.setEndLat(0.0);
            trip.setEndLng(0.0);
        }
        trip.setMemberCasual(rs.getString("member_casual"));

        if (startedAtLocal != null && endedAtLocal != null && endedAtLocal.isAfter(startedAtLocal)) {
            long durationInMinutes = ChronoUnit.MINUTES.between(startedAtLocal, endedAtLocal);
            trip.setDurationMinutes(Math.max(0, (int) durationInMinutes));
        } else {
            trip.setDurationMinutes(0);
        }
        return trip;
    }

    // Các phương thức getAllTrips, searchTrips, getTripsByYear, v.v.
    // sẽ sử dụng các cột 'start_datetime' và 'end_datetime' trong câu lệnh SELECT.
    // Ví dụ cho getAllTrips:
    public List<Trip> getAllTrips(int limit, int offset) {
        List<Trip> trips = new ArrayList<>();
        // Đảm bảo SELECT từ các cột 'start_datetime' và 'end_datetime'
        // ORDER BY trên cột VARCHAR 'start_datetime' sẽ hoạt động tốt với định dạng YYYY-MM-DD HH:MM:SS
        String sql = "SELECT ride_id, rideable_type, start_datetime, end_datetime, " +
                     "start_station_name, start_station_id, end_station_name, end_station_id, " +
                     "start_lat, start_lng, end_lat, end_lng, member_casual " +
                     "FROM all_trip_copy ORDER BY start_datetime DESC LIMIT ? OFFSET ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // ... (phần còn lại của PreparedStatement và ResultSet handling)
            pstmt.setInt(1, limit);
            pstmt.setInt(2, offset);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                trips.add(mapRowToTrip(rs));
            }
        } catch (SQLException e) {
            System.err.println("SQL Error in TripDAO - getAllTrips: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("General Error in TripDAO - getAllTrips: " + e.getMessage());
            e.printStackTrace();
        }
        return trips;
    }

    // Tương tự cho các phương thức khác, đảm bảo bạn SELECT và tham chiếu đến
    // 'start_datetime' và 'end_datetime'.
    // Với định dạng YYYY-MM-DD HH:MM:SS, hàm YEAR(start_datetime) của MySQL
    // cũng sẽ hoạt động đúng ngay cả khi cột là VARCHAR.

    public List<Trip> getTripsByYear(int year, int limit, int offset) {
        List<Trip> trips = new ArrayList<>();
        String sql = "SELECT ride_id, rideable_type, start_datetime, end_datetime, " +
                     "start_station_name, start_station_id, end_station_name, end_station_id, " +
                     "start_lat, start_lng, end_lat, end_lng, member_casual " +
                     "FROM all_trip_copy " +
                     "WHERE YEAR(start_datetime) = ? " + // Sẽ hoạt động với VARCHAR dạng YYYY-MM-DD...
                     "ORDER BY start_datetime DESC LIMIT ? OFFSET ?";
        // ... (phần còn lại)
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, year);
            pstmt.setInt(2, limit);
            pstmt.setInt(3, offset);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                trips.add(mapRowToTrip(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting trips by year " + year + ": " + e.getMessage());
            e.printStackTrace();
        }
        return trips;
    }
    // ... (các phương thức khác như getTotalTripCount, searchTrips, ...)

	public int getTotalTripCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Trip> searchTrips(String keyword, int pageSize, int offset) {
		// TODO Auto-generated method stub
		return null;
	}

	// Trong file TripDAO.java

	// ... (các phương thức khác như getAllTrips, mapRowToTrip, ...)

	public int getTotalSearchTripCount(String keyword) {
	    String searchTerm = "%" + keyword.toLowerCase() + "%";
	    // Đảm bảo tên các cột trong WHERE clause khớp với bảng của bạn
	    String sql = "SELECT COUNT(*) FROM all_trip_copy " +
	                 "WHERE LOWER(ride_id) LIKE ? " +
	                 "OR LOWER(rideable_type) LIKE ? " +
	                 "OR LOWER(start_station_name) LIKE ? " + // Hoặc cột bạn muốn tìm kiếm
	                 "OR LOWER(end_station_name) LIKE ? " +   // Hoặc cột bạn muốn tìm kiếm
	                 "OR LOWER(member_casual) LIKE ?";       // Hoặc cột bạn muốn tìm kiếm
	    System.out.println("[TripDAO - getTotalSearchTripCount] Executing SQL for keyword: " + keyword); // Dòng debug

	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        if (conn == null || conn.isClosed()) {
	            System.err.println("[TripDAO - getTotalSearchTripCount] Database connection is null or closed!");
	            return 0;
	        }

	        pstmt.setString(1, searchTerm);
	        pstmt.setString(2, searchTerm);
	        pstmt.setString(3, searchTerm);
	        pstmt.setString(4, searchTerm);
	        pstmt.setString(5, searchTerm);

	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            int total = rs.getInt(1);
	            System.out.println("[TripDAO - getTotalSearchTripCount] Found " + total + " matching trips for keyword '" + keyword + "'"); // Dòng debug
	            return total;
	        }
	    } catch (SQLException e) {
	        System.err.println("SQL Error in TripDAO - getTotalSearchTripCount for keyword '" + keyword + "': " + e.getMessage());
	        e.printStackTrace();
	    } catch (Exception e) {
	        System.err.println("General Error in TripDAO - getTotalSearchTripCount for keyword '" + keyword + "': " + e.getMessage());
	        e.printStackTrace();
	    }
	    System.out.println("[TripDAO - getTotalSearchTripCount] Returning 0 for keyword '" + keyword + "' due to error or no data."); // Dòng debug
	    return 0; // Trả về 0 nếu có lỗi hoặc không tìm thấy
	}

	// ... (các phương thức khác)


}