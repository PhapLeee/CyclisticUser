// src/main/java/com/cyclistic/service/StationService.java
package com.cyclistic.service;

import com.cyclistic.dao.StationDAO;
import com.cyclistic.model.Station;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StationService {
    private StationDAO stationDAO;
    private List<Station> cachedUniqueStations; // Cache
    private boolean stationsLoadedInitially = false; // Để biết cache đã được tải lần đầu chưa

    public StationService() {
        try {
            this.stationDAO = new StationDAO();
            System.out.println("[StationService] StationDAO initialized.");
        } catch (Exception e) {
            System.err.println("CRITICAL: Failed to initialize StationDAO in StationService: " + e.getMessage());
            e.printStackTrace();
            // Trong trường hợp thực tế, bạn có thể muốn ném một RuntimeException ở đây
            // để báo hiệu rằng service không thể hoạt động.
            // throw new RuntimeException("Failed to initialize StationDAO for StationService", e);
        }
    }

    // Tải hoặc tải lại dữ liệu vào cache
    private synchronized void loadStationsIntoCache() { // synchronized để tránh tải nhiều lần nếu gọi từ nhiều thread
        if (this.stationDAO == null) {
            System.err.println("[StationService] StationDAO is not initialized. Cannot load stations into cache.");
            this.cachedUniqueStations = Collections.emptyList();
            stationsLoadedInitially = true;
            return;
        }
        try {
            System.out.println("[StationService] Loading unique stations into cache from DAO...");
            this.cachedUniqueStations = stationDAO.getAllUniqueStationsFromTrips();
            System.out.println("[StationService] Cached " + (this.cachedUniqueStations != null ? this.cachedUniqueStations.size() : 0) + " unique stations.");
        } catch (Exception e) {
            System.err.println("[StationService] Error loading unique stations into cache: " + e.getMessage());
            e.printStackTrace();
            this.cachedUniqueStations = Collections.emptyList(); // Đảm bảo cache không null
        }
        stationsLoadedInitially = true;
    }

    /**
     * Lấy danh sách các trạm duy nhất đã được sử dụng.
     * Sẽ sử dụng cache nếu có, hoặc tải mới nếu cache chưa có hoặc đã được yêu cầu làm mới.
     * @return Danh sách các Station, có thể rỗng nhưng không bao giờ null.
     */
    public List<Station> getAllUniqueStationsUsed() {
        if (!stationsLoadedInitially || cachedUniqueStations == null) {
            loadStationsIntoCache();
        }
        // Trả về một bản sao của danh sách để bảo vệ cache
        return this.cachedUniqueStations != null ? new ArrayList<>(this.cachedUniqueStations) : Collections.emptyList();
    }

    /**
     * Yêu cầu làm mới cache dữ liệu trạm.
     * Lần gọi getAllUniqueStationsUsed() tiếp theo sẽ tải lại dữ liệu từ DAO.
     */
    public void refreshStationsCache() {
        System.out.println("[StationService] Station cache refresh requested.");
        this.cachedUniqueStations = null; // Xóa cache để buộc tải lại
        this.stationsLoadedInitially = false; // Đánh dấu là chưa tải để lần gọi sau sẽ tải
        // Có thể gọi loadStationsIntoCache() ngay tại đây nếu muốn tải lại ngay lập tức
        // loadStationsIntoCache();
    }

    /**
     * Lấy tổng số trạm duy nhất đã được sử dụng.
     * @return Số lượng trạm.
     */
    public int getTotalUniqueStationsUsedCount() {
        if (!stationsLoadedInitially || cachedUniqueStations == null) {
            loadStationsIntoCache();
        }
        return this.cachedUniqueStations != null ? this.cachedUniqueStations.size() : 0;
    }
}