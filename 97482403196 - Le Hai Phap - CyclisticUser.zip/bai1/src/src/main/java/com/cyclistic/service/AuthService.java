// src/main/java/com/cyclistic/service/AuthService.java
package com.cyclistic.service; // Đảm bảo package đúng với vị trí file của bạn

import com.cyclistic.dao.AdminUserDAO;    // Import từ package dao
import com.cyclistic.model.AdminUser;     // Import từ package model
import com.cyclistic.util.AppSession;     // Import từ package util
import com.cyclistic.util.PasswordUtil;   // Import từ package util

public class AuthService {
    // Để MainApp có thể truy cập adminUserDAO cho việc kiểm tra và tạo user mặc định ban đầu.
    // Trong một thiết kế phức tạp hơn, có thể có một phương thức service riêng cho việc đó.
    public AdminUserDAO adminUserDAO;

    public AuthService() {
        this.adminUserDAO = new AdminUserDAO();
    }

    /**
     * Xử lý logic đăng nhập của người dùng.
     * @param username Tên đăng nhập.
     * @param password Mật khẩu (dạng plain text).
     * @return true nếu đăng nhập thành công, false nếu thất bại.
     */
    public boolean login(String username, String password) {
        System.out.println("[AuthService] Login attempt for username: '" + username + "'");

        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            System.err.println("[AuthService] Username or password cannot be empty.");
            return false;
        }

        AdminUser user = adminUserDAO.findByUsername(username); // AdminUserDAO sẽ có log riêng

        if (user != null) {
            System.out.println("[AuthService] User '" + username + "' found in DB. Checking password.");
            // PasswordUtil.checkPassword sẽ tự gọi PasswordUtil.hashPassword(password) bên trong nó
            // và so sánh với user.getPasswordHash()
            if (PasswordUtil.checkPassword(password, user.getPasswordHash())) {
                AppSession.setCurrentUser(user);
                System.out.println("[AuthService] Login successful for user: " + username);
                return true;
            } else {
                // Để debug, chúng ta có thể hash lại mật khẩu nhập vào để so sánh bằng mắt trên log
                // (không làm điều này trong production với log level cao)
                String inputPasswordHashForLogging = PasswordUtil.hashPassword(password);
                System.out.println("[AuthService] Password mismatch for user: " + username +
                                   ". DB Hash: " + user.getPasswordHash().substring(0, Math.min(10, user.getPasswordHash().length())) + "..." + // Chỉ log một phần hash DB
                                   ", Input Hash (generated for comparison): " + inputPasswordHashForLogging.substring(0, Math.min(10, inputPasswordHashForLogging.length())) + "...");
            }
        } else {
            // DAO đã log "User NOT found", nhưng có thể log thêm ở đây nếu muốn
            System.out.println("[AuthService] User '" + username + "' not found by DAO during login attempt.");
        }

        System.out.println("[AuthService] Login failed for username: '" + username + "'");
        return false;
    }

    /**
     * Xử lý logic đăng xuất.
     */
    public void logout() {
        AdminUser currentUser = AppSession.getCurrentUser();
        String loggedOutUser = (currentUser != null ? "'" + currentUser.getUsername() + "'" : "Guest (no user was logged in)");
        AppSession.clearSession();
        System.out.println("[AuthService] User " + loggedOutUser + " logged out.");
    }

    /**
     * Đăng ký tài khoản admin mặc định nếu chưa tồn tại.
     * @param username Tên đăng nhập cho admin mặc định.
     * @param password Mật khẩu (plain text) cho admin mặc định.
     * @param roleId ID vai trò cho admin.
     * @return true nếu tài khoản được tạo hoặc đã tồn tại, false nếu có lỗi khi tạo.
     */
    public boolean registerDefaultAdmin(String username, String password, int roleId) {
        System.out.println("[AuthService] Attempting to register or verify default admin: '" + username + "'");

        if (adminUserDAO.findByUsername(username) != null) {
            System.out.println("[AuthService] Default admin user '" + username + "' already exists. Registration skipped by AuthService.");
            return true; // Coi như thành công nếu đã tồn tại
        }

        System.out.println("[AuthService] Default admin '" + username + "' not found, proceeding with registration.");
        String hashedPassword = PasswordUtil.hashPassword(password);
        System.out.println("[AuthService] Hashed password for default admin '" + username + "': " + hashedPassword.substring(0, Math.min(10, hashedPassword.length())) + "...");

        AdminUser newUser = new AdminUser();
        // userId sẽ được tự động tạo bởi CSDL (AUTO_INCREMENT)
        newUser.setUsername(username);
        newUser.setPasswordHash(hashedPassword);
        newUser.setRoleId(roleId);
        // email và fullName có thể để null hoặc giá trị mặc định nếu cột trong CSDL cho phép NULL
        newUser.setEmail(username + "@example.com"); // Ví dụ email
        newUser.setFullName("Default Administrator"); // Ví dụ tên đầy đủ

        boolean created = adminUserDAO.addUser(newUser); // AdminUserDAO sẽ có log riêng

        if (created) {
            System.out.println("[AuthService] Default admin '" + username + "' registered successfully by AuthService.");
        } else {
            System.err.println("[AuthService] Failed to register default admin '" + username + "' via AuthService. Check DAO logs.");
        }
        return created;
    }

    /**
     * Thay đổi mật khẩu cho người dùng hiện tại đang đăng nhập.
     * @param currentPassword Mật khẩu hiện tại (plain text) để xác minh.
     * @param newPassword Mật khẩu mới (plain text).
     * @return true nếu đổi mật khẩu thành công, false nếu mật khẩu hiện tại sai hoặc có lỗi.
     */
    public boolean changeCurrentUserPassword(String currentPassword, String newPassword) {
        AdminUser currentUser = AppSession.getCurrentUser();
        if (currentUser == null) {
            System.err.println("[AuthService] Error: No user currently logged in to change password.");
            return false;
        }

        System.out.println("[AuthService] Attempting to change password for user: '" + currentUser.getUsername() + "'");

        // 1. Xác minh mật khẩu hiện tại
        if (!PasswordUtil.checkPassword(currentPassword, currentUser.getPasswordHash())) {
            System.err.println("[AuthService] Current password verification failed for user: " + currentUser.getUsername());
            return false;
        }

        // 2. (Tùy chọn) Kiểm tra xem mật khẩu mới có khác mật khẩu cũ không
        if (currentPassword.equals(newPassword)) {
            System.out.println("[AuthService] New password is the same as the current password. No change made.");
            // Trả về true hoặc false tùy theo bạn muốn coi đây là thành công hay không
            return false; // Hoặc true nếu không muốn báo lỗi cho người dùng
        }

        // 3. Băm mật khẩu mới
        String newPasswordHash = PasswordUtil.hashPassword(newPassword);
        System.out.println("[AuthService] New password for '" + currentUser.getUsername() + "' hashed to: " + newPasswordHash.substring(0, Math.min(10, newPasswordHash.length())) + "...");

        // 4. Gọi DAO để cập nhật mật khẩu trong CSDL
        boolean updatedInDb = adminUserDAO.updatePassword(currentUser.getUserId(), newPasswordHash); // AdminUserDAO sẽ có log

        if (updatedInDb) {
            // 5. Cập nhật password hash trong đối tượng User của session hiện tại
            currentUser.setPasswordHash(newPasswordHash);
            // AppSession.setCurrentUser(currentUser); // Không cần thiết nếu đối tượng currentUser là tham chiếu được cập nhật
            System.out.println("[AuthService] Password changed successfully in DB and session for user: " + currentUser.getUsername());
            return true;
        } else {
            System.err.println("[AuthService] Failed to update password in DB for user: " + currentUser.getUsername() + ". Check DAO logs.");
            return false;
        }
    }

    // TODO: Thêm các phương thức quản lý người dùng khác nếu cần thiết, ví dụ:
    // - Cập nhật thông tin hồ sơ người dùng (email, full_name)
    // - Admin reset mật khẩu cho người dùng khác
    // - Lấy danh sách tất cả người dùng (có thể cần một UserService riêng)
}