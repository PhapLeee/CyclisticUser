// src/main/java/com/cyclistic/ui/StationManagementPanel.java
package com.cyclistic.ui;

import com.cyclistic.model.Station;
import com.cyclistic.service.StationService; // Đảm bảo StationService này là phiên bản bạn đang dùng cho Swing

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;

public class StationManagementPanel extends JPanel {
    private JTable stationTable;
    private DefaultTableModel tableModel;
    private StationService stationService;
    private JButton refreshButton;
    private JLabel infoLabel;

    public StationManagementPanel() {
        // Quan trọng: Đảm bảo StationService() này được khởi tạo đúng
        // và là phiên bản tương thích với logic Swing này.
        try {
            this.stationService = new StationService();
        } catch (Exception e) {
            // Xử lý lỗi nghiêm trọng nếu service không khởi tạo được
            e.printStackTrace();
            // Hiển thị lỗi cho người dùng nếu cần
            this.setLayout(new BorderLayout());
            this.add(new JLabel("Error: Station Service could not be initialized. " + e.getMessage(), SwingConstants.CENTER), BorderLayout.CENTER);
            return; // Không khởi tạo phần còn lại của UI
        }

        setLayout(new BorderLayout(5, 5));
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel topPanel = new JPanel(new BorderLayout());
        refreshButton = new JButton("Refresh Data");
        refreshButton.addActionListener(e -> loadStationData());

        infoLabel = new JLabel("Loading station data...");
        infoLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        topPanel.add(refreshButton, BorderLayout.WEST);
        topPanel.add(infoLabel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        String[] columnNames = {"Station ID", "Station Name", "Latitude", "Longitude"}; // Bỏ Capacity nếu không có
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        stationTable = new JTable(tableModel);
        stationTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        stationTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        stationTable.getColumnModel().getColumn(1).setPreferredWidth(350);
        stationTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        stationTable.getColumnModel().getColumn(3).setPreferredWidth(100);

        JScrollPane scrollPane = new JScrollPane(stationTable);
        add(scrollPane, BorderLayout.CENTER);

        loadStationData();
    }

    private void loadStationData() {
        if (stationService == null) {
            infoLabel.setText("Error: Station Service not available.");
            System.err.println("[StationManagementPanel] StationService is null. Cannot load data.");
            return;
        }

        System.out.println("[StationManagementPanel] Loading station data...");
        tableModel.setRowCount(0); // Xóa dữ liệu cũ trong bảng

        // SỬA Ở ĐÂY: Gọi đúng tên phương thức trong StationService
        List<Station> stations = stationService.getAllUniqueStationsUsed();

        System.out.println("[StationManagementPanel] Received " + (stations != null ? stations.size() : "null") + " unique stations from service.");

        if (stations != null && !stations.isEmpty()) {
            DecimalFormat df = new DecimalFormat("#.######");
            for (Station station : stations) {
                // Model Station cần có các getter getStationId, getStationName, getLatitude, getLongitude
                // Và constructor của Station trong DAO cần xử lý giá trị capacity (nếu có)
                Object[] row = {
                        station.getStationId(),
                        station.getStationName(),
                        (station.getLatitude() == 0.0 && station.getLongitude() == 0.0 && (station.getStationName() == null || !station.getStationName().toLowerCase().contains("hq"))) ? "N/A" : df.format(station.getLatitude()),
                        (station.getLatitude() == 0.0 && station.getLongitude() == 0.0 && (station.getStationName() == null || !station.getStationName().toLowerCase().contains("hq"))) ? "N/A" : df.format(station.getLongitude()),
                };
                tableModel.addRow(row);
            }
            infoLabel.setText("Total Unique Stations: " + stations.size());
        } else {
            System.out.println("[StationManagementPanel] No unique stations found or service returned empty/null.");
            infoLabel.setText("No stations found.");
        }
    }

    public void refreshTableData() {
        System.out.println("[StationManagementPanel] Refreshing station data...");
        loadStationData();
    }
}