// src/main/java/com/cyclistic/ui/controller/ReportController.java
package com.cyclistic.ui.controller;

import com.cyclistic.service.ReportService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos; // Import Pos
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.Pane; // Import Pane
import javafx.scene.layout.Region; // Import Region
import javafx.scene.layout.StackPane; // Import StackPane

import java.util.ArrayList; // Import ArrayList
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
// import java.util.List; // Không cần nếu không có Top Routes
import java.util.Map;
import java.util.stream.Collectors;

public class ReportController {

    private ReportService reportService;
    private static final int TOP_STATIONS_LIMIT = 5;

    @FXML private Button refreshAllChartsButton;

    @FXML private PieChart memberTypePieChart;
    @FXML private BarChart<String, Number> avgDurationChart;    // X:String (Category), Y:Number
    @FXML private BarChart<String, Number> rideableTypeChart; // X:String (Category), Y:Number

    // Cho Horizontal Bar Charts: X là Number, Y là String (Category)
    @FXML private BarChart<Number, String> topStartStationsChart;
    @FXML private BarChart<Number, String> topEndStationsChart;

    // Các @FXML cho Axis không bắt buộc nếu không tùy chỉnh riêng, FXML sẽ tự tạo chúng.
    // Nếu bạn muốn truy cập chúng từ code, hãy bỏ comment và đảm bảo fx:id khớp FXML.
    // @FXML private CategoryAxis avgDurationXAxis;
    // @FXML private NumberAxis avgDurationYAxis;
    // @FXML private CategoryAxis rideableTypeXAxis;
    // @FXML private NumberAxis rideableTypeYAxis;
    // @FXML private CategoryAxis topStartStationsYAxis_Cat; // Trục Y (dọc) của biểu đồ ngang
    // @FXML private NumberAxis topStartStationsXAxis_Num;   // Trục X (ngang) của biểu đồ ngang
    // @FXML private CategoryAxis topEndStationsYAxis_Cat;
    // @FXML private NumberAxis topEndStationsXAxis_Num;


    @FXML
    private void initialize() {
        System.out.println("[ReportController] Initializing with simplified charts (Horizontal Top Stations)...");
        try {
            reportService = new ReportService();
            System.out.println("[ReportController] ReportService initialized.");
        } catch (Exception e) {
            System.err.println("[ReportController] CRITICAL: Failed to initialize ReportService.");
            e.printStackTrace();
            // TODO: Hiển thị lỗi rõ ràng hơn trên UI nếu service không khởi tạo được
            return;
        }
        refreshAllCharts();
        System.out.println("[ReportController] Initial data loading initiated.");
    }

    @FXML
    private void handleRefreshAllCharts() {
        System.out.println("[ReportController] Refresh All Charts button clicked.");
        refreshAllCharts();
    }

    private void refreshAllCharts() {
        System.out.println("[ReportController] Refreshing 5 charts...");
        loadMemberTypePieChartData();
        loadAvgDurationChartData();
        loadRideableTypeChartData();
        loadTopStartStationsChartData();
        loadTopEndStationsChartData();
    }

    // --- Các hàm load dữ liệu cho từng biểu đồ ---

    private void loadMemberTypePieChartData() {
        if (reportService == null) {
             System.err.println("[ReportController] loadMemberTypePieChartData - ReportService is null!");
             addNoDataLabelToChart(memberTypePieChart.getParent(), "Service Error."); // Sử dụng getParent()
            return;
        }
        Map<String, Integer> memberData = reportService.getTripCountsByMemberType();
        System.out.println("[ReportController] Data for MemberTypePieChart from Service: " + memberData);

        memberTypePieChart.getData().clear();
        if (memberData == null || memberData.isEmpty()) {
            System.out.println("[ReportController] No member type data to display.");
            addNoDataLabelToChart(memberTypePieChart.getParent(), "No data for User Types.");
            return;
        }
        removeNoDataLabelFromChart(memberTypePieChart.getParent());

        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
        for (Map.Entry<String, Integer> entry : memberData.entrySet()) {
            if (entry.getValue() > 0) {
                 String label = entry.getKey().substring(0, 1).toUpperCase() + entry.getKey().substring(1) + " (" + String.format("%,d", entry.getValue()) + ")";
                pieChartData.add(new PieChart.Data(label, entry.getValue()));
            }
        }
        memberTypePieChart.setData(pieChartData);
        addTooltipsToPieChart(memberTypePieChart);
    }

    private void loadAvgDurationChartData() {
        if (reportService == null) {
            System.err.println("[ReportController] loadAvgDurationChartData - ReportService is null!");
            addNoDataLabelToChart(avgDurationChart.getParent(), "Service Error.");
            return;
        }
        Map<String, Double> avgDurationData = reportService.getAverageTripDurationByMemberType();
        System.out.println("[ReportController] Data for AvgDurationChart from Service: " + avgDurationData);

        avgDurationChart.getData().clear();
        if (avgDurationData == null || avgDurationData.isEmpty()) {
            System.out.println("[ReportController] No average duration data to display.");
            addNoDataLabelToChart(avgDurationChart.getParent(), "No data for Average Duration.");
            return;
        }
        removeNoDataLabelFromChart(avgDurationChart.getParent());

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (Map.Entry<String, Double> entry : avgDurationData.entrySet()) {
             String userType = entry.getKey().substring(0, 1).toUpperCase() + entry.getKey().substring(1);
            series.getData().add(new XYChart.Data<>(userType, entry.getValue()));
        }
        System.out.println("[ReportController] AvgDurationChart - Series final size: " + series.getData().size());
        if (!series.getData().isEmpty()) {
            avgDurationChart.getData().add(series);
            addTooltipsToBarChart(avgDurationChart, "min", null);
        } else {
            addNoDataLabelToChart(avgDurationChart.getParent(), "No valid data points for Average Duration.");
        }
    }

    private void loadRideableTypeChartData() {
        if (reportService == null) {
             System.err.println("[ReportController] loadRideableTypeChartData - ReportService is null!");
             addNoDataLabelToChart(rideableTypeChart.getParent(), "Service Error.");
            return;
        }
        Map<String, Integer> rideableTypeData = reportService.getTripCountsByRideableType();
        System.out.println("[ReportController] Data for RideableTypeChart from Service: " + rideableTypeData);

        rideableTypeChart.getData().clear();
        if (rideableTypeData == null || rideableTypeData.isEmpty()) {
            System.out.println("[ReportController] No rideable type data to display.");
            addNoDataLabelToChart(rideableTypeChart.getParent(), "No data for Rideable Types.");
            return;
        }
        removeNoDataLabelFromChart(rideableTypeChart.getParent());

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        LinkedHashMap<String, Integer> sortedMap = rideableTypeData.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
        for (Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
            if (entry.getValue() > 0) {
                series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
            }
        }
        System.out.println("[ReportController] RideableTypeChart - Series final size: " + series.getData().size());
        if (!series.getData().isEmpty()){
            rideableTypeChart.getData().add(series);
            addTooltipsToBarChart(rideableTypeChart, "trips", rideableTypeData);
        } else {
            addNoDataLabelToChart(rideableTypeChart.getParent(), "No valid data points for Rideable Types.");
        }
    }

    private void loadTopStartStationsChartData() {
        System.out.println("--- Loading data for: TopStartStationsChart (Top " + TOP_STATIONS_LIMIT + ") ---");
        if (reportService == null) {
             System.err.println("[ReportController] loadTopStartStationsChartData - ReportService is null!");
             addNoDataLabelToChart(topStartStationsChart.getParent(), "Service Error.");
            return;
        }
        Map<String, Integer> topStationsData = reportService.getTopStartStations(TOP_STATIONS_LIMIT);
        System.out.println("[ReportController] Data for TopStartStationsChart from Service (Size: " + (topStationsData != null ? topStationsData.size() : "null") + ")");

        topStartStationsChart.getData().clear();
        if (topStationsData == null || topStationsData.isEmpty()) {
            System.out.println("[ReportController] No top start stations data to display.");
            addNoDataLabelToChart(topStartStationsChart.getParent(), "No data for Top " + TOP_STATIONS_LIMIT + " Start Stations.");
            return;
        }
        removeNoDataLabelFromChart(topStartStationsChart.getParent());

        XYChart.Series<Number, String> series = new XYChart.Series<>(); // Y là String (CategoryAxis), X là Number (NumberAxis)
        LinkedHashMap<String, Integer> sortedMap = topStationsData.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder())) // Sắp xếp theo giá trị (count) giảm dần
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        // Để thanh cao nhất ở trên cùng trong biểu đồ ngang, ta thêm dữ liệu vào series theo thứ tự ngược lại
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(sortedMap.entrySet());
        for (int i = entries.size() - 1; i >= 0; i--) {
            Map.Entry<String, Integer> entry = entries.get(i);
            series.getData().add(new XYChart.Data<>(entry.getValue(), truncateStationName(entry.getKey()))); // (Number, String)
        }

        System.out.println("[ReportController] TopStartStationsChart - Series final size: " + series.getData().size());
        if (!series.getData().isEmpty()) {
            topStartStationsChart.getData().add(series);
            addTooltipsToHorizontalBarChart(topStartStationsChart, "starts", topStationsData);
        } else {
            addNoDataLabelToChart(topStartStationsChart.getParent(), "No valid data points for Top Start Stations.");
        }
        System.out.println("--- Finished loading TopStartStationsChartData ---");
    }

    private void loadTopEndStationsChartData() {
        System.out.println("--- Loading data for: TopEndStationsChart (Top " + TOP_STATIONS_LIMIT + ") ---");
        if (reportService == null) {
            System.err.println("[ReportController] loadTopEndStationsChartData - ReportService is null!");
            addNoDataLabelToChart(topEndStationsChart.getParent(), "Service Error.");
            return;
        }
        Map<String, Integer> topStationsData = reportService.getTopEndStations(TOP_STATIONS_LIMIT);
        System.out.println("[ReportController] Data for TopEndStationsChart from Service (Size: " + (topStationsData != null ? topStationsData.size() : "null") + ")");

        topEndStationsChart.getData().clear();
        if (topStationsData == null || topStationsData.isEmpty()) {
            System.out.println("[ReportController] No top end stations data to display.");
            addNoDataLabelToChart(topEndStationsChart.getParent(), "No data for Top " + TOP_STATIONS_LIMIT + " End Stations.");
            return;
        }
        removeNoDataLabelFromChart(topEndStationsChart.getParent());

        XYChart.Series<Number, String> series = new XYChart.Series<>(); // Y là String (CategoryAxis), X là Number (NumberAxis)
        LinkedHashMap<String, Integer> sortedMap = topStationsData.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        List<Map.Entry<String, Integer>> entries = new ArrayList<>(sortedMap.entrySet());
        for (int i = entries.size() - 1; i >= 0; i--) {
            Map.Entry<String, Integer> entry = entries.get(i);
            series.getData().add(new XYChart.Data<>(entry.getValue(), truncateStationName(entry.getKey()))); // (Number, String)
        }

        System.out.println("[ReportController] TopEndStationsChart - Series final size: " + series.getData().size());
         if (!series.getData().isEmpty()) {
            topEndStationsChart.getData().add(series);
            addTooltipsToHorizontalBarChart(topEndStationsChart, "ends", topStationsData);
        } else {
            addNoDataLabelToChart(topEndStationsChart.getParent(), "No valid data points for Top End Stations.");
        }
        System.out.println("--- Finished loading TopEndStationsChartData ---");
    }

    // --- Helper methods ---
    private String truncateStationName(String name) {
        if (name == null) return "N/A";
        int maxLength = 30; // Tăng lên một chút cho tên trạm trên thanh ngang
        return name.length() > maxLength ? name.substring(0, maxLength - 3) + "..." : name;
    }

    // Tooltip cho BarChart đứng (X là String, Y là Number)
    private void addTooltipsToBarChart(BarChart<String, Number> chart, String unit, Map<String, ? extends Number> originalDataMap) {
        for (XYChart.Series<String, Number> series : chart.getData()) {
            for (XYChart.Data<String, Number> data : series.getData()) {
                String truncatedXValue = data.getXValue();
                String originalXValue = truncatedXValue;

                if (originalDataMap != null && !(originalDataMap.isEmpty())) { // Kiểm tra map không null và không rỗng
                    for (Map.Entry<String, ? extends Number> entry : originalDataMap.entrySet()) {
                        // So sánh tên đã cắt ngắn của key trong map với XValue của data point
                        if (truncateStationName(entry.getKey()).equals(truncatedXValue) &&
                            (entry.getValue() != null && data.getYValue() != null && entry.getValue().doubleValue() == data.getYValue().doubleValue())) {
                            originalXValue = entry.getKey();
                            break;
                        } else if (entry.getKey().equals(truncatedXValue) && // Trường hợp XValue không bị cắt (ví dụ Rideable Type)
                                   (entry.getValue() != null && data.getYValue() != null && entry.getValue().doubleValue() == data.getYValue().doubleValue())) {
                            originalXValue = entry.getKey();
                            break;
                        }
                    }
                }
                Tooltip tooltip = new Tooltip(String.format("%s\n(%,.0f %s)", originalXValue, data.getYValue().doubleValue(), unit));
                Tooltip.install(data.getNode(), tooltip);
            }
        }
    }

    // Tooltip cho BarChart ngang (X là Number, Y là String)
    private void addTooltipsToHorizontalBarChart(BarChart<Number, String> chart, String unit, Map<String, Integer> originalDataMap) {
        for (XYChart.Series<Number, String> series : chart.getData()) {
            for (XYChart.Data<Number, String> data : series.getData()) {
                String truncatedYValue = data.getYValue(); // Tên trạm (đã cắt ngắn) giờ là YValue
                String originalYValue = truncatedYValue;

                if (originalDataMap != null && !originalDataMap.isEmpty()) {
                     for (Map.Entry<String, Integer> entry : originalDataMap.entrySet()) {
                        if (truncateStationName(entry.getKey()).equals(truncatedYValue) &&
                            (entry.getValue() != null && data.getXValue() != null && entry.getValue().doubleValue() == data.getXValue().doubleValue())) {
                            originalYValue = entry.getKey();
                            break;
                        }
                    }
                }
                Tooltip tooltip = new Tooltip(String.format("%s\n(%,.0f %s)", originalYValue, data.getXValue().doubleValue(), unit));
                Tooltip.install(data.getNode(), tooltip);
            }
        }
    }

    private void addTooltipsToPieChart(PieChart chart) {
        double total = chart.getData().stream().mapToDouble(PieChart.Data::getPieValue).sum();
        if (total == 0) return;
        chart.getData().forEach(data -> {
            String seriesName = data.getName().split(" \\(")[0];
            String tooltipText = String.format("%s: %.2f%%\n(%,.0f)", seriesName, (data.getPieValue() / total) * 100, data.getPieValue());
            Tooltip.install(data.getNode(), new Tooltip(tooltipText));
        });
    }

    private void addNoDataLabelToChart(Node chartContainerNode, String message) {
        if (chartContainerNode instanceof Pane) {
            Pane container = (Pane) chartContainerNode;
            container.getChildren().removeIf(node -> node.getStyleClass().contains("no-data-label"));
            container.getChildren().stream()
                .filter(node -> node instanceof Chart)
                .findFirst()
                .ifPresent(chartNode -> {
                    chartNode.setVisible(false);
                    chartNode.setManaged(false);
                });
            Label noDataLabel = new Label(message);
            noDataLabel.getStyleClass().add("no-data-label");
            noDataLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #666666; -fx-padding: 20px; -fx-border-color: #dddddd; -fx-border-style: dashed; -fx-background-color: #f9f9f9;");
            if (container instanceof StackPane) {
                StackPane.setAlignment(noDataLabel, Pos.CENTER);
            } else if (container instanceof Region) {
                noDataLabel.setMaxWidth(Double.MAX_VALUE);
                noDataLabel.setAlignment(Pos.CENTER);
            }
            container.getChildren().add(noDataLabel);
        } else {
            System.err.println("[ReportController] addNoDataLabelToChart: chartContainerNode is not a Pane. Type: " + (chartContainerNode != null ? chartContainerNode.getClass().getName() : "null"));
        }
    }

    private void removeNoDataLabelFromChart(Node chartContainerNode) {
        if (chartContainerNode instanceof Pane) {
            Pane container = (Pane) chartContainerNode;
            container.getChildren().removeIf(node -> node.getStyleClass().contains("no-data-label"));
            container.getChildren().stream()
                .filter(node -> node instanceof Chart)
                .findFirst()
                .ifPresent(chartNode -> {
                    chartNode.setVisible(true);
                    chartNode.setManaged(true);
                });
        } else {
             System.err.println("[ReportController] removeNoDataLabelFromChart: chartContainerNode is not a Pane. Type: " + (chartContainerNode != null ? chartContainerNode.getClass().getName() : "null"));
        }
    }
}