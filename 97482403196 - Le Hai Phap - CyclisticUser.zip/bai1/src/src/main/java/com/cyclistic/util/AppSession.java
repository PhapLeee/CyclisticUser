package com.cyclistic.util;
import com.cyclistic.model.AdminUser; // Đảm bảo import đúng

public class AppSession {
    private static AdminUser currentUser;
    private AppSession() {}
    public static void setCurrentUser(AdminUser user) { currentUser = user; }
    public static AdminUser getCurrentUser() { return currentUser; }
    public static void clearSession() { currentUser = null; }
    public static boolean isLoggedIn() { return currentUser != null; }
}