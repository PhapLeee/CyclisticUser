package com.cyclistic.ui.controller; // Hoặc package controller JavaFX của bạn

import com.ccyclistic.MainApp; // ĐÚNG MainApp JavaFX
import com.cyclistic.service.AuthService; // Đảm bảo AuthService ở đúng package
import com.cyclistic.util.AppSession; // Nếu dùng AppSession
// import com.cyclistic.model.AdminUser; // Nếu cần lấy thông tin user

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Label statusLabel;

    private AuthService authService; // Khai báo

    @FXML
    private void initialize() {
        statusLabel.setText("");
        try {
            // Khởi tạo AuthService ở đây.
            // Đảm bảo DBConnection và các phụ thuộc khác của AuthService đã sẵn sàng.
            authService = new AuthService();
            System.out.println("[LoginController] AuthService initialized.");
        } catch (Exception e) {
            System.err.println("[LoginController] FATAL: Could not initialize AuthService.");
            e.printStackTrace();
            statusLabel.setText("Error: Auth Service unavailable.");
            statusLabel.getStyleClass().remove("success-label");
            statusLabel.getStyleClass().add("status-label");
            if (loginButton != null) {
                loginButton.setDisable(true);
            }
        }
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        System.out.println("[LoginController] handleLogin called. User: " + username);

        if (authService == null) {
            statusLabel.setText("Error: Authentication service not available.");
            statusLabel.getStyleClass().remove("success-label");
            statusLabel.getStyleClass().add("status-label");
            System.err.println("[LoginController] authService is null during login attempt.");
            return;
        }

        try {
            // Sử dụng phương thức login() từ AuthService của bạn
            // (trong code AuthService bạn gửi, phương thức đó tên là login(), không phải authenticate())
            boolean isAuthenticated = authService.login(username, password); // SỬA Ở ĐÂY
            System.out.println("[LoginController] Authentication result for " + username + ": " + isAuthenticated);

            if (isAuthenticated) {
                statusLabel.setText("Login Successful!");
                statusLabel.getStyleClass().remove("status-label");
                statusLabel.getStyleClass().add("success-label");

                // Lấy thông tin người dùng từ AppSession nếu cần hiển thị hoặc dùng sau này
                // AdminUser currentUser = AppSession.getCurrentUser();
                // if (currentUser != null) {
                //     System.out.println("[LoginController] Current user from session: " + currentUser.getUsername());
                // }

                // Chuyển màn hình
                new Thread(() -> { // Dùng Thread để không block UI nếu có delay
                    try {
                        Thread.sleep(500); // Delay nhỏ để người dùng thấy thông báo
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        e.printStackTrace();
                    }
                    javafx.application.Platform.runLater(() -> {
                        if (MainApp.getInstance() != null) {
                            MainApp.getInstance().showMainDashboard();
                        } else {
                            System.err.println("[LoginController] FATAL: MainApp instance is null. Cannot switch to dashboard.");
                            statusLabel.setText("Critical error. Cannot proceed.");
                        }
                    });
                }).start();

            } else {
                statusLabel.setText("Invalid username or password.");
                statusLabel.getStyleClass().remove("success-label");
                statusLabel.getStyleClass().add("status-label");
                passwordField.clear();
                usernameField.requestFocus();
            }
        } catch (Exception e) {
            System.err.println("[LoginController] Exception during login process for user " + username);
            e.printStackTrace();
            statusLabel.setText("Error during authentication. Please try again or check logs.");
            statusLabel.getStyleClass().remove("success-label");
            statusLabel.getStyleClass().add("status-label");
        }
    }
}