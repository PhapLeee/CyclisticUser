// src/main/java/com/cyclistic/util/DBConnection.java
package com.cyclistic.util; 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // --- THAY ĐỔI TÊN DATABASE Ở ĐÂY ---
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/source?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"; // SỬA "soure" THÀNH "source"
    private static final String USERNAME = "root"; // Giữ nguyên nếu đúng
    private static final String PASSWORD = "123456"; // Giữ nguyên nếu đúng
    // ------------------------------------

    private DBConnection() {}

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found. Please add MySQL Connector JAR to your project.");
            e.printStackTrace();
            throw new SQLException("MySQL JDBC Driver not found.", e);
        }
        return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
    }

    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            if (connection != null && !connection.isClosed()) {
                System.out.println("Successfully connected to the database: " + connection.getCatalog());
                // connection.getCatalog() sẽ trả về "source" nếu kết nối thành công
            } else {
                System.err.println("Failed to make connection to the database.");
            }
        } catch (SQLException e) {
            System.err.println("SQL Exception occurred during connection test:");
            e.printStackTrace();
        }
    }
}