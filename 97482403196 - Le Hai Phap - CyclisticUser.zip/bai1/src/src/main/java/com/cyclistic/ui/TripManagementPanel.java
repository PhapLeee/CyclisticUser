// src/main/java/com/cyclistic/ui/TripManagementPanel.java
package com.cyclistic.ui;

import com.cyclistic.model.Trip;
import com.cyclistic.service.TripService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter; // Thêm nếu bạn dùng để lọc
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TripManagementPanel extends JPanel {
    private JTable tripTable;
    private DefaultTableModel tableModel;
    private TripService tripService;

    private JButton prevButton, nextButton, searchButton, clearSearchButton, refreshButton;
    private JTextField searchField;
    private JLabel pageInfoLabel;
    private int currentPage = 1;
    private final int PAGE_SIZE = 50;
    private String currentSearchKeyword = "";

    private JScrollPane scrollPane; // Khai báo ở mức lớp
    private JLabel noDataLabel;     // Khai báo ở mức lớp
    private TableRowSorter<DefaultTableModel> sorter; // Nếu bạn có chức năng lọc/sắp xếp

    public TripManagementPanel() {
        System.out.println("[TripManagementPanel] Initializing...");
        try {
            this.tripService = new TripService();
        } catch (ExceptionInInitializerError | NoClassDefFoundError e) {
            System.err.println("[TripManagementPanel] CRITICAL ERROR: Failed to initialize TripService.");
            e.printStackTrace();
            setLayout(new BorderLayout());
            add(new JLabel("Error initializing TripService. Check console for details.", SwingConstants.CENTER), BorderLayout.CENTER);
            return;
        }

        setLayout(new BorderLayout(5, 5));
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JPanel topPanel = new JPanel(new BorderLayout(10,0));
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(25);
        searchButton = new JButton("Search");
        clearSearchButton = new JButton("Clear");
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearSearchButton);
        refreshButton = new JButton("Refresh All Data");
        topPanel.add(searchPanel, BorderLayout.WEST);
        topPanel.add(refreshButton, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        String[] columnNames = {"Ride ID", "Rideable Type", "Started At", "Ended At", "Start Station", "End Station", "Member/Casual", "Duration (min)"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tripTable = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel); // Khởi tạo sorter
        tripTable.setRowSorter(sorter);             // Gán sorter cho table

        tripTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tripTable.getColumnModel().getColumn(0).setPreferredWidth(150);
        tripTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        tripTable.getColumnModel().getColumn(2).setPreferredWidth(160);
        tripTable.getColumnModel().getColumn(3).setPreferredWidth(160);
        tripTable.getColumnModel().getColumn(4).setPreferredWidth(200);
        tripTable.getColumnModel().getColumn(5).setPreferredWidth(200);
        tripTable.getColumnModel().getColumn(6).setPreferredWidth(100);
        tripTable.getColumnModel().getColumn(7).setPreferredWidth(100);

        // Khởi tạo noDataLabel
        noDataLabel = new JLabel("No trip data available.", SwingConstants.CENTER);
        noDataLabel.setForeground(Color.GRAY);
        noDataLabel.setFont(new Font("SansSerif", Font.ITALIC, 14));

        scrollPane = new JScrollPane(); // Khởi tạo JScrollPane
        add(scrollPane, BorderLayout.CENTER); // Thêm scrollPane vào panel

        JPanel paginationPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        prevButton = new JButton("<< Previous");
        nextButton = new JButton("Next >>");
        pageInfoLabel = new JLabel();
        paginationPanel.add(prevButton);
        paginationPanel.add(pageInfoLabel);
        paginationPanel.add(nextButton);
        add(paginationPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> {
            currentSearchKeyword = "";
            searchField.setText("");
            currentPage = 1;
            loadTripData();
        });
        searchButton.addActionListener(e -> performSearch());
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performSearch();
                }
            }
        });
        clearSearchButton.addActionListener(e -> {
            searchField.setText("");
            currentSearchKeyword = "";
            currentPage = 1;
            loadTripData();
        });
        prevButton.addActionListener(e -> { if (currentPage > 1) { currentPage--; loadTripData(); } });
        nextButton.addActionListener(e -> {
            int totalItems = currentSearchKeyword.isEmpty() ? tripService.getTotalTripCount() : tripService.getTotalSearchTripCount(currentSearchKeyword);
            int totalPages = (int) Math.ceil((double) totalItems / PAGE_SIZE);
            if (totalPages == 0) totalPages = 1;
            if (currentPage < totalPages) {
                 currentPage++;
                 loadTripData();
            }
        });

        System.out.println("[TripManagementPanel] Initialization complete. Loading initial data...");
        loadTripData();
    }

    private void performSearch() {
        currentSearchKeyword = searchField.getText().trim();
        currentPage = 1;
        loadTripData();
    }

    private void loadTripData() {
        System.out.println("[TripManagementPanel] Loading data. Page: " + currentPage + ", Keyword: '" + currentSearchKeyword + "'");
        tableModel.setRowCount(0);
        List<Trip> trips;

        if (tripService == null) {
            System.err.println("[TripManagementPanel] TripService is null. Cannot load data.");
            JOptionPane.showMessageDialog(this, "Error: Trip Service not available.", "Service Error", JOptionPane.ERROR_MESSAGE);
            scrollPane.setViewportView(noDataLabel); // Hiển thị label lỗi
            noDataLabel.setText("Error: Trip Service not available.");
            updatePaginationControlsOnError();
            return;
        }

        if (currentSearchKeyword.isEmpty()) {
            trips = tripService.getAllTrips(currentPage, PAGE_SIZE);
        } else {
            trips = tripService.searchTrips(currentSearchKeyword, currentPage, PAGE_SIZE);
        }
        System.out.println("[TripManagementPanel] Received " + (trips != null ? trips.size() : "null") + " trips from service.");

        if (trips != null && !trips.isEmpty()) {
            scrollPane.setViewportView(tripTable); // Hiển thị JTable nếu có dữ liệu
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            for (Trip trip : trips) {
                Object[] row = {
                    trip.getRideId(), trip.getRideableType(),
                    trip.getStartedAt() != null ? trip.getStartedAt().format(formatter) : "N/A",
                    trip.getEndedAt() != null ? trip.getEndedAt().format(formatter) : "N/A",
                    trip.getStartStationName(), trip.getEndStationName(),
                    trip.getMemberCasual(),
                    (trip.getDurationMinutes() == 0 && (trip.getStartedAt() == null || trip.getEndedAt() == null || !trip.getEndedAt().isAfter(trip.getStartedAt())))
                        ? "N/A"
                        : trip.getDurationMinutes()
                };
                tableModel.addRow(row);
            }
        } else {
            scrollPane.setViewportView(noDataLabel); // Hiển thị noDataLabel nếu không có dữ liệu
            if (currentSearchKeyword.isEmpty() && currentPage == 1) {
                 noDataLabel.setText("No trip data found in the database.");
            } else {
                 noDataLabel.setText("No trips found for the current criteria.");
            }
            System.out.println("[TripManagementPanel] No trips to display.");
        }
        updatePaginationControls();
    }

    private void updatePaginationControlsOnError() {
        pageInfoLabel.setText("Page 1 of 1 (Error)");
        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
    }

    public void refreshTableData() {
        currentSearchKeyword = "";
        searchField.setText("");
        currentPage = 1;
        System.out.println("[TripManagementPanel] Refreshing all trip data, resetting to page 1...");
        loadTripData();
    }

    private void updatePaginationControls() {
        if (tripService == null) {
            updatePaginationControlsOnError();
            return;
        }
        int totalItems;
        if (currentSearchKeyword.isEmpty()) {
            totalItems = tripService.getTotalTripCount();
        } else {
            totalItems = tripService.getTotalSearchTripCount(currentSearchKeyword);
        }
        int totalPages = (int) Math.ceil((double) totalItems / PAGE_SIZE);
        if (totalPages == 0) totalPages = 1;

        pageInfoLabel.setText("Page " + currentPage + " of " + totalPages + " (Total: " + totalItems + ")");
        prevButton.setEnabled(currentPage > 1);
        nextButton.setEnabled(currentPage < totalPages);
        System.out.println("[TripManagementPanel] Pagination updated. CurrentPage: " + currentPage + ", TotalPages: " + totalPages + ", TotalItems: " + totalItems);
    }
}