// src/main/java/com/cyclistic/ui/MainDashboardFrame.java
package com.cyclistic.ui; // Hoặc package UI của bạn, ví dụ: com.yourgroup.bikeshare.ui

import com.cyclistic.service.AuthService;     // Thay com.cyclistic bằng package gốc của bạn nếu khác
import com.cyclistic.service.ReportService;   // Thay com.cyclistic bằng package gốc của bạn nếu khác
import com.cyclistic.util.AppSession;         // Thay com.cyclistic bằng package gốc của bạn nếu khác
// ChartPanel từ JFreeChart sẽ được ChartPanelFactory trả về
// Không cần import org.jfree.chart.ChartPanel trực tiếp ở đây nếu không dùng ở phạm vi class

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Map;

public class MainDashboardFrame extends JFrame {
    private JTabbedPane tabbedPane;
    private AuthService authService;
    private ReportService reportService; // Khởi tạo một lần

    // Các panel cho từng tab
    private TripManagementPanel tripManagementPanel;
    private StationManagementPanel stationManagementPanel;
    private JPanel reportPanel; // Panel chính cho tab Reports
    private JPanel chartDisplayArea; // Panel con trong reportPanel để hiển thị biểu đồ

    public MainDashboardFrame() {
        this.authService = new AuthService();
        this.reportService = new ReportService();

        setTitle("Cyclistic Data Analyzer - Dashboard (Logged in as: " +
                (AppSession.isLoggedIn() && AppSession.getCurrentUser() != null ? AppSession.getCurrentUser().getUsername() : "Guest") + ")");
        setSize(1000, 800); // Kích thước cửa sổ
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Căn giữa màn hình

        // --- Menu Bar ---
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutItem.addActionListener(e -> performLogout());

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(logoutItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
        // -----------------

        tabbedPane = new JTabbedPane();

        // Tab Trip Management
        tripManagementPanel = new TripManagementPanel();
        tabbedPane.addTab("Trip Management", tripManagementPanel);

        // Tab Station Management
        stationManagementPanel = new StationManagementPanel();
        tabbedPane.addTab("Station Management", stationManagementPanel);

        // Tab Reports
        setupReportPanel();
        tabbedPane.addTab("Reports", reportPanel);

        add(tabbedPane, BorderLayout.CENTER);
    }

    private void setupReportPanel() {
        reportPanel = new JPanel(new BorderLayout(10, 10));
        reportPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // Panel điều khiển cho báo cáo
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        Integer currentYear = Calendar.getInstance().get(Calendar.YEAR);
        Integer[] years = new Integer[5];
        for (int i = 0; i < 5; i++) {
            years[i] = currentYear - i;
        }
        JComboBox<Integer> yearComboBox = new JComboBox<>(years);
        yearComboBox.setPreferredSize(new Dimension(100, yearComboBox.getPreferredSize().height));

        JButton generateMonthlyReportButton = new JButton("Trips by Month");
        JButton generateMemberTypeReportButton = new JButton("Trips by Member Type");
        JButton generateAvgDurationButton = new JButton("Avg Trip Duration"); // Rút gọn tên nút
        JButton generateRideableTypeReportButton = new JButton("Trips by Rideable Type");
        JButton generateHourlyActivityButton = new JButton("Hourly Activity"); // Rút gọn tên nút

        controlPanel.add(new JLabel("Year (for monthly):"));
        controlPanel.add(yearComboBox);
        controlPanel.add(generateMonthlyReportButton);
        controlPanel.add(generateMemberTypeReportButton);
        controlPanel.add(generateAvgDurationButton);
        controlPanel.add(generateRideableTypeReportButton);
        controlPanel.add(generateHourlyActivityButton);
        reportPanel.add(controlPanel, BorderLayout.NORTH);

        // Panel để hiển thị biểu đồ
        chartDisplayArea = new JPanel(new BorderLayout());
        chartDisplayArea.setBorder(BorderFactory.createEtchedBorder());
        reportPanel.add(chartDisplayArea, BorderLayout.CENTER);

        // Action cho nút "Trips by Month"
        generateMonthlyReportButton.addActionListener(e -> {
            Integer selectedYear = (Integer) yearComboBox.getSelectedItem();
            if (selectedYear != null) {
                Map<String, Integer> monthlyData = reportService.getTripCountsByMonthForYear(selectedYear);
                if (monthlyData == null || monthlyData.isEmpty()){
                    JOptionPane.showMessageDialog(this, "No trip data found for year " + selectedYear + " for monthly report.", "Report Info", JOptionPane.INFORMATION_MESSAGE);
                    updateChartDisplay(null);
                } else {
                    org.jfree.chart.ChartPanel barChartPanel = ChartPanelFactory.createMonthlyTripsBarChart(
                            "Trip Counts for " + selectedYear, monthlyData);
                    updateChartDisplay(barChartPanel);
                }
            }
        });

        // Action cho nút "Trips by Member Type"
        generateMemberTypeReportButton.addActionListener(e -> {
            Map<String, Integer> memberData = reportService.getTripCountsByMemberType();
             if (memberData == null || memberData.isEmpty()){
                JOptionPane.showMessageDialog(this, "No trip data found for member type report.", "Report Info", JOptionPane.INFORMATION_MESSAGE);
                updateChartDisplay(null);
            } else {
                org.jfree.chart.ChartPanel pieChartPanel = ChartPanelFactory.createMemberTypePieChart(
                        "Trip Distribution by Member Type (Overall)", memberData);
                updateChartDisplay(pieChartPanel);
            }
        });

        // Action cho nút "Avg Trip Duration by Member"
        generateAvgDurationButton.addActionListener(e -> {
            Map<String, Double> avgDurationData = reportService.getAverageTripDurationByMemberType();
            if (avgDurationData == null || avgDurationData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No data found for average trip duration report.", "Report Info", JOptionPane.INFORMATION_MESSAGE);
                updateChartDisplay(null);
            } else {
                org.jfree.chart.ChartPanel avgDurationChart = ChartPanelFactory.createAverageDurationBarChart(
                        "Average Trip Duration by Member Type", avgDurationData);
                updateChartDisplay(avgDurationChart);
            }
        });

        // Action cho nút "Trips by Rideable Type"
        generateRideableTypeReportButton.addActionListener(e -> {
            Map<String, Integer> rideableTypeData = reportService.getTripCountsByRideableType();
            if (rideableTypeData == null || rideableTypeData.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No data found for trip counts by rideable type.", "Report Info", JOptionPane.INFORMATION_MESSAGE);
                updateChartDisplay(null);
            } else {
                org.jfree.chart.ChartPanel rideableTypeChart = ChartPanelFactory.createRideableTypeBarChart(
                        "Trip Counts by Rideable Type", rideableTypeData);
                updateChartDisplay(rideableTypeChart);
            }
        });

        // Action cho nút "Hourly Activity by User Type"
        generateHourlyActivityButton.addActionListener(e -> {
            Map<String, Map<Integer, Integer>> hourlyData = reportService.getHourlyActivityByUserType();
            // Kiểm tra cẩn thận hơn cho map lồng nhau
            boolean noMemberData = hourlyData == null || hourlyData.get("member") == null || hourlyData.get("member").values().stream().allMatch(count -> count == 0);
            boolean noCasualData = hourlyData == null || hourlyData.get("casual") == null || hourlyData.get("casual").values().stream().allMatch(count -> count == 0);

            if (noMemberData && noCasualData) {
                JOptionPane.showMessageDialog(this, "No data found for hourly activity report.", "Report Info", JOptionPane.INFORMATION_MESSAGE);
                updateChartDisplay(null);
            } else {
                org.jfree.chart.ChartPanel hourlyChart = ChartPanelFactory.createHourlyActivityLineChart(
                        "Hourly Ride Activity by User Type", hourlyData);
                updateChartDisplay(hourlyChart);
            }
        });

        // Tự động hiển thị một báo cáo mặc định khi mở tab
        SwingUtilities.invokeLater(() -> {
             if (generateMemberTypeReportButton.getActionListeners().length > 0) { // Đảm bảo listener đã được add
                generateMemberTypeReportButton.doClick();
            }
        });
    }

    private void updateChartDisplay(org.jfree.chart.ChartPanel chartPanelToShow) {
        if (chartDisplayArea == null) {
            System.err.println("Lỗi nghiêm trọng: chartDisplayArea chưa được khởi tạo trong MainDashboardFrame khi gọi updateChartDisplay.");
            // Khởi tạo lại chartDisplayArea nếu nó null một cách bất thường
            chartDisplayArea = new JPanel(new BorderLayout());
            if (reportPanel != null && reportPanel.getLayout() instanceof BorderLayout) {
                 reportPanel.add(chartDisplayArea, BorderLayout.CENTER);
                 System.out.println("[MainDashboardFrame] Đã thử khởi tạo lại chartDisplayArea.");
            } else {
                System.err.println("[MainDashboardFrame] Không thể thêm chartDisplayArea vào reportPanel do reportPanel null hoặc layout không phù hợp.");
                return;
            }
        }
        chartDisplayArea.removeAll();
        if (chartPanelToShow != null) {
            chartDisplayArea.add(chartPanelToShow, BorderLayout.CENTER);
        }
        chartDisplayArea.revalidate();
        chartDisplayArea.repaint();
    }

    private void performLogout() {
        authService.logout();
        JOptionPane.showMessageDialog(this, "Logged out successfully.");
        this.dispose();
        new LoginFrame().setVisible(true); // Đảm bảo LoginFrame đã được import đúng
    }
}