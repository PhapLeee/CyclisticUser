// src/main/java/com/cyclistic/service/ReportService.java
package com.cyclistic.service; // Hoặc package service của bạn

import com.cyclistic.util.DBConnection; // Hoặc package util của bạn

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Month;            // Để lấy tên tháng
import java.time.format.TextStyle; // Để định dạng tên tháng
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;            // Để lấy tên tháng theo ngôn ngữ cụ thể
import java.util.Map;

public class ReportService {

    // Lớp nội bộ RouteData (giữ nguyên hoặc tùy chỉnh nếu cần)
    public static class RouteData {
        private String startStationName;
        private String endStationName;
        private int count;

        public RouteData(String start, String end, int c) {
            this.startStationName = start;
            this.endStationName = end;
            this.count = c;
        }

        public String getStartStationName() { return startStationName; }
        public String getEndStationName() { return endStationName; }
        public int getCount() { return count; }

        @Override
        public String toString() {
            String start = (startStationName != null && startStationName.length() > 25) ? startStationName.substring(0, 22) + "..." : (startStationName == null ? "N/A" : startStationName);
            String end = (endStationName != null && endStationName.length() > 25) ? endStationName.substring(0, 22) + "..." : (endStationName == null ? "N/A" : endStationName);
            return start + " -> " + end + " (" + count + ")";
        }
    }

    public ReportService() {
        // Constructor
    }

    /**
     * Lấy số lượng chuyến đi theo tháng cho một năm cụ thể.
     * Dữ liệu được lấy trực tiếp từ bảng 'all_trip_copy'.
     * @param year Năm cần lấy dữ liệu.
     * @return Map với key là tên tháng (ví dụ: "January") và value là số lượng chuyến đi.
     */
    public Map<String, Integer> getTripCountsByMonthForYear(int year) {
        Map<String, Integer> monthlyData = new LinkedHashMap<>();
        // Khởi tạo map với tất cả các tháng, giá trị mặc định là 0
        for (int i = 1; i <= 12; i++) {
            monthlyData.put(Month.of(i).getDisplayName(TextStyle.FULL, Locale.ENGLISH), 0);
        }

        // Đảm bảo tên bảng 'all_trip_copy' và cột 'started_at', 'ride_id' là đúng
        String sql = "SELECT MONTH(started_at) AS ride_month_num, COUNT(ride_id) AS trip_count " +
                     "FROM all_trip_copy " + // THAY THẾ 'all_trip_copy' NẾU TÊN BẢNG CỦA BẠN KHÁC
                     "WHERE YEAR(started_at) = ? " +
                     "GROUP BY ride_month_num " +
                     "ORDER BY ride_month_num ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, year);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int monthNum = rs.getInt("ride_month_num");
                int tripCount = rs.getInt("trip_count");
                if (monthNum >= 1 && monthNum <= 12) { // Đảm bảo số tháng hợp lệ
                    String monthName = Month.of(monthNum).getDisplayName(TextStyle.FULL, Locale.ENGLISH);
                    monthlyData.put(monthName, tripCount);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting trip counts by month for year " + year + ": " + e.getMessage());
            e.printStackTrace(); // Xem xét logging chi tiết hơn trong môi trường production
        }
        return monthlyData;
    }

    /**
     * Lấy số lượng chuyến đi theo tháng trong một khoảng ngày cụ thể.
     * @param startDate Ngày bắt đầu (bao gồm).
     * @param endDate Ngày kết thúc (bao gồm).
     * @return Map với key là "YYYY-MM" và value là số lượng chuyến đi.
     */
    public Map<String, Integer> getTripCountsByMonthForDateRange(LocalDate startDate, LocalDate endDate) {
        Map<String, Integer> tripCounts = new LinkedHashMap<>();
        // Đảm bảo tên bảng 'all_trip_copy' và cột 'started_at', 'ride_id' là đúng
        String sql = "SELECT DATE_FORMAT(started_at, '%Y-%m') AS ride_month, COUNT(ride_id) AS trip_count " +
                     "FROM all_trip_copy " + // THAY THẾ 'all_trip_copy' NẾU TÊN BẢNG CỦA BẠN KHÁC
                     "WHERE DATE(started_at) BETWEEN ? AND ? " +
                     "GROUP BY ride_month " +
                     "ORDER BY ride_month ASC";

        if (startDate == null || endDate == null || endDate.isBefore(startDate)) {
            System.err.println("[ReportService] Invalid date range provided for getTripCountsByMonthForDateRange.");
            return tripCounts; // Trả về map rỗng
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDate(1, java.sql.Date.valueOf(startDate));
            pstmt.setDate(2, java.sql.Date.valueOf(endDate));

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                tripCounts.put(rs.getString("ride_month"), rs.getInt("trip_count"));
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting trip counts by month for date range: " + e.getMessage());
            e.printStackTrace();
        }
        return tripCounts;
    }

    /**
     * Lấy số lượng chuyến đi theo loại thành viên.
     * Đọc từ bảng tổng hợp `user_type_distribution`.
     * @return Map với key là loại thành viên và value là số lượng chuyến đi.
     */
    public Map<String, Integer> getTripCountsByMemberType() {
        Map<String, Integer> tripCounts = new LinkedHashMap<>();
        // KIỂM TRA CSDL: Tên bảng 'user_type_distribution' và các cột 'member_casual', 'count(*)' (hoặc tên cột đếm của bạn)
        // Ví dụ: Nếu cột đếm của bạn là 'total_users', hãy thay `count(*)\` AS trip_count` thành `total_users AS trip_count`
        String sql = "SELECT member_casual, `count(*)` AS trip_count FROM user_type_distribution";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String memberType = rs.getString("member_casual");
                int count = rs.getInt("trip_count");
                if (memberType != null && !memberType.trim().isEmpty()) {
                    tripCounts.put(memberType, count);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting trip counts by member type: " + e.getMessage());
            e.printStackTrace();
        }
        return tripCounts;
    }

    /**
     * Lấy thời gian chuyến đi trung bình (phút) theo loại thành viên.
     * Đọc từ bảng tổng hợp `average_ride_duration_by_user`.
     * @return Map với key là loại thành viên và value là thời gian trung bình (phút).
     */
    public Map<String, Double> getAverageTripDurationByMemberType() {
        Map<String, Double> avgDurations = new LinkedHashMap<>();
        // KIỂM TRA CSDL: Tên bảng 'average_ride_duration_by_user' và các cột 'member_casual', 'avg(TIMESTAMPDIFF...)' (hoặc tên cột thời gian TB của bạn)
        // Ví dụ: Nếu cột thời gian TB của bạn là 'avg_duration', hãy thay thế phần tính toán bằng tên cột đó.
        String sql = "SELECT member_casual, `avg(TIMESTAMPDIFF(minute, start_datetime, end_datetime))` AS avg_duration_minutes FROM average_ride_duration_by_user";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String memberType = rs.getString("member_casual");
                double avgDuration = rs.getDouble("avg_duration_minutes");
                if (memberType != null && !memberType.trim().isEmpty()) {
                    avgDurations.put(memberType, avgDuration);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting average trip duration by member type: " + e.getMessage());
            e.printStackTrace();
        }
        return avgDurations;
    }

    /**
     * Lấy số lượng chuyến đi theo loại xe (rideable_type).
     * Dữ liệu được lấy trực tiếp từ bảng 'all_trip_copy'.
     * @return Map với key là rideable_type và value là số lượng chuyến đi.
     */
    public Map<String, Integer> getTripCountsByRideableType() {
        Map<String, Integer> rideableTypeCounts = new LinkedHashMap<>();
        // Đảm bảo tên bảng 'all_trip_copy' và cột 'rideable_type', 'ride_id' là đúng.
        String sql = "SELECT rideable_type, COUNT(ride_id) AS trip_count " +
                     "FROM all_trip_copy " + // THAY THẾ 'all_trip_copy' NẾU TÊN BẢNG CỦA BẠN KHÁC
                     "WHERE rideable_type IS NOT NULL AND rideable_type != '' " +
                     "GROUP BY rideable_type " +
                     "ORDER BY trip_count DESC";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String rideableType = rs.getString("rideable_type");
                int count = rs.getInt("trip_count");
                // Kiểm tra lại cho chắc chắn, dù SQL đã lọc
                if (rideableType != null && !rideableType.trim().isEmpty()) {
                     rideableTypeCounts.put(rideableType, count);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting trip counts by rideable type: " + e.getMessage());
            e.printStackTrace();
        }
        return rideableTypeCounts;
    }


    /**
     * Lấy hoạt động hàng giờ theo loại người dùng.
     * Đọc từ bảng tổng hợp `hourly_activity_by_user`.
     * @return Map lồng nhau: Key ngoài là loại người dùng ("member", "casual"),
     *         value là một Map khác với key là giờ (0-23) và value là số lượng chuyến đi.
     */
    public Map<String, Map<Integer, Integer>> getHourlyActivityByUserType() {
        Map<String, Map<Integer, Integer>> hourlyActivity = new LinkedHashMap<>();
        // Chỉ định rõ các loại người dùng mong muốn
        hourlyActivity.put("member", new LinkedHashMap<>());
        hourlyActivity.put("casual", new LinkedHashMap<>());

        // Khởi tạo tất cả các giờ với count = 0 cho các loại người dùng đã định
        for (String userTypeKey : hourlyActivity.keySet()) {
            for (int i = 0; i < 24; i++) {
                hourlyActivity.get(userTypeKey).put(i, 0);
            }
        }

        // KIỂM TRA CSDL: Tên bảng 'hourly_activity_by_user' và các cột 'member_casual', 'hour_of_day', 'ride_count'
        String sql = "SELECT member_casual, hour_of_day, ride_count FROM hourly_activity_by_user ORDER BY member_casual, hour_of_day";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String memberType = rs.getString("member_casual");
                int hourOfDay = rs.getInt("hour_of_day");
                int rideCount = rs.getInt("ride_count");

                // Chỉ cập nhật nếu memberType nằm trong danh sách theo dõi (member, casual) và giờ hợp lệ
                if (hourlyActivity.containsKey(memberType) && hourOfDay >=0 && hourOfDay < 24) {
                    hourlyActivity.get(memberType).put(hourOfDay, rideCount);
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting hourly activity by user type: " + e.getMessage());
            e.printStackTrace();
        }
        return hourlyActivity;
    }

    // --- PHƯƠNG THỨC CHO TOP ROUTES ---

    private List<RouteData> getTopRoutesGeneric(String sql, int limit, String errorMsgPrefix) {
        List<RouteData> topRoutes = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String startStation = rs.getString("start_station_name");
                String endStation = rs.getString("end_station_name");
                int count = rs.getInt("route_count");

                // Chỉ thêm nếu cả hai trạm đều không null (hoặc có thể cho phép 1 trong 2 null tùy yêu cầu)
                if (startStation != null && endStation != null) {
                    topRoutes.add(new RouteData(startStation, endStation, count));
                } else if (startStation != null) { // Trường hợp chỉ có trạm bắt đầu (ít phổ biến cho "route")
                     topRoutes.add(new RouteData(startStation, "N/A", count));
                } else if (endStation != null) { // Trường hợp chỉ có trạm kết thúc
                     topRoutes.add(new RouteData("N/A", endStation, count));
                }
                // Bỏ qua nếu cả hai đều null (dù câu SQL đã có WHERE)
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] " + errorMsgPrefix + ": " + e.getMessage());
            e.printStackTrace();
        }
        return topRoutes;
    }


    public List<RouteData> getTopOverallRoutes(int limit) {
        // KIỂM TRA CSDL: Tên bảng 'top_routes_overall' và cột số lượng (ví dụ: 'number_of_users' hoặc 'trip_count')
        String sql = "SELECT start_station_name, end_station_name, number_of_users AS route_count " +
                     "FROM top_routes_overall " +
                     "WHERE start_station_name IS NOT NULL OR end_station_name IS NOT NULL " + // Ít nhất một trạm phải có tên
                     "ORDER BY route_count DESC LIMIT ?";
        return getTopRoutesGeneric(sql, limit, "Error getting top overall routes");
    }

    public List<RouteData> getTopCasualRoutes(int limit) {
        // KIỂM TRA CSDL: Tên bảng 'top_routes_casual' và cột số lượng
        String sql = "SELECT start_station_name, end_station_name, number_of_users AS route_count " +
                     "FROM top_routes_casual " +
                     "WHERE start_station_name IS NOT NULL OR end_station_name IS NOT NULL " +
                     "ORDER BY route_count DESC LIMIT ?";
        return getTopRoutesGeneric(sql, limit, "Error getting top casual routes");
    }

    public List<RouteData> getTopMemberRoutes(int limit) {
        // KIỂM TRA CSDL: Tên bảng 'top_routes_member' và cột số lượng
        String sql = "SELECT start_station_name, end_station_name, number_of_users AS route_count " +
                     "FROM top_routes_member " +
                     "WHERE start_station_name IS NOT NULL OR end_station_name IS NOT NULL " +
                     "ORDER BY route_count DESC LIMIT ?";
        return getTopRoutesGeneric(sql, limit, "Error getting top member routes");
    }


    // --- CÁC PHƯƠNG THỨC TIỆN ÍCH HOẶC BÁO CÁO KHÁC (TÙY CHỌN) ---

    /**
     * Lấy các trạm bắt đầu phổ biến nhất.
     * Truy vấn từ bảng 'all_trip_copy'.
     * @param limit Số lượng trạm hàng đầu cần lấy.
     * @return Map với key là tên trạm và value là số lượng chuyến đi bắt đầu từ đó.
     */
    public Map<String, Integer> getTopStartStations(int limit) {
        Map<String, Integer> topStations = new LinkedHashMap<>();
        // Đảm bảo tên bảng 'all_trip_copy' và cột 'start_station_name', 'ride_id' là đúng
        String sql = "SELECT start_station_name, COUNT(ride_id) AS trip_count " +
                     "FROM all_trip_copy " + // THAY THẾ 'all_trip_copy' NẾU TÊN BẢNG CỦA BẠN KHÁC
                     "WHERE start_station_name IS NOT NULL AND start_station_name != '' " +
                     "GROUP BY start_station_name " +
                     "ORDER BY trip_count DESC " +
                     "LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String stationName = rs.getString("start_station_name");
                if (stationName != null && !stationName.trim().isEmpty()){ // Kiểm tra lại
                     topStations.put(stationName, rs.getInt("trip_count"));
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting top start stations: " + e.getMessage());
            e.printStackTrace();
        }
        return topStations;
    }

     /**
     * Lấy các trạm kết thúc phổ biến nhất.
     * Truy vấn từ bảng 'all_trip_copy'.
     * @param limit Số lượng trạm hàng đầu cần lấy.
     * @return Map với key là tên trạm và value là số lượng chuyến đi kết thúc tại đó.
     */
    public Map<String, Integer> getTopEndStations(int limit) {
        Map<String, Integer> topStations = new LinkedHashMap<>();
        // Đảm bảo tên bảng 'all_trip_copy' và cột 'end_station_name', 'ride_id' là đúng
        String sql = "SELECT end_station_name, COUNT(ride_id) AS trip_count " +
                     "FROM all_trip_copy " + // THAY THẾ 'all_trip_copy' NẾU TÊN BẢNG CỦA BẠN KHÁC
                     "WHERE end_station_name IS NOT NULL AND end_station_name != '' " +
                     "GROUP BY end_station_name " +
                     "ORDER BY trip_count DESC " +
                     "LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String stationName = rs.getString("end_station_name");
                 if (stationName != null && !stationName.trim().isEmpty()){ // Kiểm tra lại
                    topStations.put(stationName, rs.getInt("trip_count"));
                }
            }
        } catch (SQLException e) {
            System.err.println("[ReportService] Error getting top end stations: " + e.getMessage());
            e.printStackTrace();
        }
        return topStations;
    }
}