// src/main/java/com/cyclistic/ui/ChartPanelFactory.java
package com.cyclistic.ui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator; // Cho định dạng label của PieChart

import java.awt.Color;
import java.awt.Dimension;
import java.awt.BasicStroke; // Cho độ dày đường
import java.text.DecimalFormat;
import java.text.NumberFormat; // Cho định dạng phần trăm của PieChart
import java.util.Map;

public class ChartPanelFactory {

    public static ChartPanel createMonthlyTripsBarChart(String title, Map<String, Integer> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        if (data != null) {
            for (Map.Entry<String, Integer> entry : data.entrySet()) {
                dataset.addValue(entry.getValue(), "Trips", entry.getKey());
            }
        }
        JFreeChart barChart = ChartFactory.createBarChart(title, "Month (YYYY-MM)", "Number of Trips",
                dataset, PlotOrientation.VERTICAL, false, true, false);
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(750, 450));
        return chartPanel;
    }

    public static ChartPanel createMemberTypePieChart(String title, Map<String, Integer> data) {
        DefaultPieDataset<String> dataset = new DefaultPieDataset<>();
        if (data != null) {
            for (Map.Entry<String, Integer> entry : data.entrySet()) {
                if (entry.getKey() != null && !entry.getKey().trim().isEmpty()) {
                    dataset.setValue(entry.getKey(), entry.getValue());
                }
            }
        }
        JFreeChart pieChart = ChartFactory.createPieChart(title, dataset, true, true, false);
        // Tùy chỉnh hiển thị phần trăm trên PieChart
        org.jfree.chart.plot.PiePlot plot = (org.jfree.chart.plot.PiePlot) pieChart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {1} ({2})", NumberFormat.getNumberInstance(), NumberFormat.getPercentInstance()));
        plot.setSimpleLabels(true); // Tránh label chồng chéo
        plot.setNoDataMessage("No data available");

        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new Dimension(550, 400)); // Tăng kích thước một chút
        return chartPanel;
    }

    public static ChartPanel createAverageDurationBarChart(String title, Map<String, Double> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        if (data != null) {
            for (Map.Entry<String, Double> entry : data.entrySet()) {
                if (entry.getKey() != null && !entry.getKey().trim().isEmpty()) {
                    dataset.addValue(entry.getValue(), "Average Duration (minutes)", entry.getKey());
                }
            }
        }
        JFreeChart barChart = ChartFactory.createBarChart(title, "Member Type", "Average Duration (minutes)",
                dataset, PlotOrientation.VERTICAL, false, true, false);
        CategoryPlot plot = barChart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        DecimalFormat df = new DecimalFormat("#.##");
        renderer.setDefaultToolTipGenerator(new StandardCategoryToolTipGenerator(
            "{1}: {2} " + "minutes", df
        ));
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(600, 400));
        return chartPanel;
    }

    public static ChartPanel createRideableTypeBarChart(String title, Map<String, Integer> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        String seriesKey = "Number of Trips";
        if (data != null) {
            for (Map.Entry<String, Integer> entry : data.entrySet()) {
                if (entry.getKey() != null && !entry.getKey().trim().isEmpty()) {
                    dataset.addValue(entry.getValue(), seriesKey, entry.getKey());
                }
            }
        }
        JFreeChart barChart = ChartFactory.createBarChart(title, "Rideable Type", "Number of Trips",
                dataset, PlotOrientation.VERTICAL, true, true, false);
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(700, 450));
        return chartPanel;
    }

    public static ChartPanel createHourlyActivityLineChart(String title, Map<String, Map<Integer, Integer>> data) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        if (data != null) {
            for (Map.Entry<String, Map<Integer, Integer>> userTypeEntry : data.entrySet()) {
                String userType = userTypeEntry.getKey();
                Map<Integer, Integer> hourlyData = userTypeEntry.getValue();
                for (int hour = 0; hour < 24; hour++) {
                    Integer count = hourlyData.getOrDefault(hour, 0);
                    dataset.addValue(count, userType, String.format("%02d:00", hour)); // Định dạng giờ cho đẹp: 00:00, 01:00,...
                }
            }
        }

        JFreeChart lineChart = ChartFactory.createLineChart(
                title, "Hour of Day", "Number of Rides",
                dataset, PlotOrientation.VERTICAL, true, true, false);

        CategoryPlot plot = lineChart.getCategoryPlot();
        LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
        renderer.setDefaultShapesVisible(true);
        renderer.setDrawOutlines(true);
        renderer.setUseFillPaint(true);

        // Phân biệt màu cho các series (member vs casual)
        if (dataset.getRowIndex("member") >= 0) { // Kiểm tra series "member" có tồn tại không
            renderer.setSeriesPaint(dataset.getRowIndex("member"), new Color(51,102,204)); // Màu xanh cho member
            renderer.setSeriesStroke(dataset.getRowIndex("member"), new BasicStroke(2.0f));
        }
        if (dataset.getRowIndex("casual") >= 0) { // Kiểm tra series "casual" có tồn tại không
            renderer.setSeriesPaint(dataset.getRowIndex("casual"), new Color(220,57,18)); // Màu cam/đỏ cho casual
            renderer.setSeriesStroke(dataset.getRowIndex("casual"), new BasicStroke(2.0f));
        }
        
        // Đảm bảo trục Y là số nguyên
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());


        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new Dimension(800, 500)); // Tăng kích thước biểu đồ này
        return chartPanel;
    }
}