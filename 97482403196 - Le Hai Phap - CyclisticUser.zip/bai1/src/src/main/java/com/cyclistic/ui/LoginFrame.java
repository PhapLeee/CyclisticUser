package com.cyclistic.ui;

import com.cyclistic.service.AuthService; // Đảm bảo import đúng

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private AuthService authService;

    public LoginFrame() {
        this.authService = new AuthService();

        setTitle("Cyclistic Data Analyzer - Login"); // Sửa lại tên ứng dụng nếu cần
        setSize(350, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        inputPanel.add(usernameField);

        inputPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        inputPanel.add(passwordField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        loginButton = new JButton("Login");
        buttonPanel.add(loginButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(e -> performLogin());
        passwordField.addActionListener(e -> performLogin()); // Login bằng Enter
    }

    private void performLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (authService.login(username, password)) {
            JOptionPane.showMessageDialog(LoginFrame.this,
                    "Login Successful!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            MainDashboardFrame dashboard = new MainDashboardFrame(); // Import com.ccyclistic.ui.MainDashboardFrame
            dashboard.setVisible(true);
            LoginFrame.this.dispose();
        } else {
            JOptionPane.showMessageDialog(LoginFrame.this,
                    "Invalid username or password.",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}