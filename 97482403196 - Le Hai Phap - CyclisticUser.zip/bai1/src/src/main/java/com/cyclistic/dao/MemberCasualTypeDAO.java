// src/main/java/com/ccyclistic/dao/MemberCasualTypeDAO.java
package com.cyclistic.dao;

import com.cyclistic.model.MemberCasualType;
import com.cyclistic.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MemberCasualTypeDAO {

    // findById, findByName, getAllTypes, addMemberCasualType
    // Tương tự như BikeRideableTypeDAO, chỉ thay đổi tên lớp và tên bảng
    public MemberCasualType findById(int id) {
        String sql = "SELECT * FROM member_casual_types WHERE id = ?";
        MemberCasualType type = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                type = new MemberCasualType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return type;
    }

    public MemberCasualType findByName(String typeName) {
        String sql = "SELECT * FROM member_casual_types WHERE type_name = ?";
        MemberCasualType type = null;
         try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, typeName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                type = new MemberCasualType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return type;
    }
    
    public int getOrCreateMemberCasualTypeId(String typeName) {
        MemberCasualType existingType = findByName(typeName);
        if (existingType != null) {
            return existingType.getId();
        } else {
            MemberCasualType newType = new MemberCasualType(0, typeName);
            if (addMemberCasualType(newType)) {
                return newType.getId();
            }
        }
        return -1; 
    }


    public List<MemberCasualType> getAllTypes() {
        List<MemberCasualType> types = new ArrayList<>();
        String sql = "SELECT * FROM member_casual_types ORDER BY type_name";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                MemberCasualType type = new MemberCasualType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
                types.add(type);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return types;
    }

    public boolean addMemberCasualType(MemberCasualType type) {
        String sql = "INSERT INTO member_casual_types (type_name) VALUES (?) ON DUPLICATE KEY UPDATE type_name=VALUES(type_name)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, type.getTypeName());
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                if (type.getId() == 0) { 
                    MemberCasualType insertedType = findByName(type.getTypeName());
                    if(insertedType != null) type.setId(insertedType.getId());
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding member casual type: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}