// src/main/java/com/cyclistic/service/TripService.java
package com.cyclistic.service;

import com.cyclistic.dao.TripDAO;
import com.cyclistic.model.Trip;
import java.util.Collections;
import java.util.List;

public class TripService {
     private TripDAO tripDAO;

     public TripService() {
         // Khởi tạo DAO, đảm bảo không có lỗi ở đây
         try {
             this.tripDAO = new TripDAO();
         } catch (ExceptionInInitializerError | NoClassDefFoundError e) {
             System.err.println("CRITICAL ERROR: Failed to initialize TripDAO in TripService.");
             e.printStackTrace();
             // Có thể ném một RuntimeException ở đây để báo hiệu lỗi nghiêm trọng
             throw new RuntimeException("Failed to initialize TripDAO for TripService", e);
         }
     }

     // ĐẢM BẢO PHƯƠNG THỨC NÀY TỒN TẠI VÀ ĐÚNG THAM SỐ
     public List<Trip> getAllTrips(int pageNumber, int pageSize) {
         if (this.tripDAO == null) {
             System.err.println("[TripService] TripDAO is null in getAllTrips. Cannot fetch data.");
             return Collections.emptyList();
         }
         try {
             int offset = (pageNumber - 1) * pageSize;
             return tripDAO.getAllTrips(pageSize, offset); // Gọi DAO với pageSize và offset
         } catch (Exception e) {
             System.err.println("Error in TripService getting all trips: " + e.getMessage());
             e.printStackTrace();
             return Collections.emptyList();
         }
     }

     public int getTotalTripCount() {
        if (this.tripDAO == null) {
             System.err.println("[TripService] TripDAO is null in getTotalTripCount. Cannot fetch data.");
             return 0;
         }
        try {
            return tripDAO.getTotalTripCount();
        } catch (Exception e) {
            System.err.println("Error in TripService getting total trip count: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
     }

    // ĐẢM BẢO PHƯƠNG THỨC NÀY TỒN TẠI VÀ ĐÚNG THAM SỐ
    public List<Trip> searchTrips(String keyword, int pageNumber, int pageSize) {
        if (this.tripDAO == null) {
             System.err.println("[TripService] TripDAO is null in searchTrips. Cannot fetch data.");
             return Collections.emptyList();
         }
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllTrips(pageNumber, pageSize);
        }
        try {
            int offset = (pageNumber - 1) * pageSize;
            return tripDAO.searchTrips(keyword, pageSize, offset); // Gọi DAO với pageSize và offset
        } catch (Exception e) {
            System.err.println("Error in TripService searching trips: " + e.getMessage());
            e.printStackTrace();
            return Collections.emptyList();
        }
    }

    public int getTotalSearchTripCount(String keyword) {
        if (this.tripDAO == null) {
             System.err.println("[TripService] TripDAO is null in getTotalSearchTripCount. Cannot fetch data.");
             return 0;
         }
        if (keyword == null || keyword.trim().isEmpty()) {
            return getTotalTripCount();
        }
        try {
            return tripDAO.getTotalSearchTripCount(keyword);
        } catch (Exception e) {
            System.err.println("Error in TripService getting total search trip count: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }
}