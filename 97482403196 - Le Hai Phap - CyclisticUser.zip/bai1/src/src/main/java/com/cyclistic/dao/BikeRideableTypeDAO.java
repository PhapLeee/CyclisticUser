// src/main/java/com/ccyclistic/dao/BikeRideableTypeDAO.java
package com.cyclistic.dao;

import com.cyclistic.model.BikeRideableType;
import com.cyclistic.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BikeRideableTypeDAO {

    public BikeRideableType findById(int id) {
        String sql = "SELECT * FROM bike_rideable_types WHERE id = ?";
        BikeRideableType type = null;
        // ... (Tương tự SystemRoleDAO.findById)
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                type = new BikeRideableType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return type;
    }

    public BikeRideableType findByName(String typeName) {
        String sql = "SELECT * FROM bike_rideable_types WHERE type_name = ?";
        BikeRideableType type = null;
        // ... (Tương tự SystemRoleDAO.findByName)
         try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, typeName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                type = new BikeRideableType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return type;
    }
    
    public int getOrCreateRideableTypeId(String typeName) {
        BikeRideableType existingType = findByName(typeName);
        if (existingType != null) {
            return existingType.getId();
        } else {
            BikeRideableType newType = new BikeRideableType(0, typeName);
            if (addRideableType(newType)) { // addRideableType sẽ set ID cho newType
                return newType.getId();
            }
        }
        return -1; // Hoặc ném exception nếu không tạo được
    }

    public List<BikeRideableType> getAllTypes() {
        List<BikeRideableType> types = new ArrayList<>();
        String sql = "SELECT * FROM bike_rideable_types ORDER BY type_name";
        // ... (Tương tự SystemRoleDAO.getAllRoles)
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                BikeRideableType type = new BikeRideableType();
                type.setId(rs.getInt("id"));
                type.setTypeName(rs.getString("type_name"));
                types.add(type);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return types;
    }

    public boolean addRideableType(BikeRideableType type) {
        String sql = "INSERT INTO bike_rideable_types (type_name) VALUES (?) ON DUPLICATE KEY UPDATE type_name=VALUES(type_name)";
        // ON DUPLICATE KEY UPDATE hữu ích khi import, nếu type_name là UNIQUE
        // Nếu không, dùng INSERT INTO ... VALUES (?) và kiểm tra tồn tại trước
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, type.getTypeName());
            int affectedRows = pstmt.executeUpdate();
             if (affectedRows > 0) {
                // Lấy ID được tạo nếu là INSERT mới (không phải UPDATE từ ON DUPLICATE)
                // Điều này phức tạp hơn với ON DUPLICATE KEY UPDATE.
                // Cách đơn giản hơn là sau đó gọi findByName để lấy ID.
                if (type.getId() == 0) { // Nếu là new type và chưa có ID
                    BikeRideableType insertedType = findByName(type.getTypeName());
                    if(insertedType != null) type.setId(insertedType.getId());
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding bike rideable type: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}