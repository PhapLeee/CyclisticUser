// src/main/java/com/cyclistic/dao/AdminUserDAO.java
package com.cyclistic.dao; // Đảm bảo package đúng

import com.cyclistic.model.AdminUser;  
import com.cyclistic.util.DBConnection; // Đảm bảo import đúng

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; // Thêm import này nếu dùng getAllUsers
import java.util.ArrayList; // Thêm import này nếu dùng getAllUsers
import java.util.List;    // Thêm import này nếu dùng getAllUsers


public class AdminUserDAO {

    public AdminUser findByUsername(String username) {
        // LOGGING: Ghi log khi bắt đầu tìm kiếm user
        System.out.println("[AdminUserDAO] Attempting to find user by username: " + username);

        String sql = "SELECT user_id, username, password_hash, email, full_name, role_id FROM adminusers WHERE username = ?";
        AdminUser user = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                user = new AdminUser();
                user.setUserId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPasswordHash(rs.getString("password_hash"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRoleId(rs.getInt("role_id"));
                // LOGGING: Ghi log thông tin user tìm thấy và hash từ DB
                System.out.println("[AdminUserDAO] User found: " + user.getUsername() +
                                   ", DB Password Hash: " + user.getPasswordHash() +
                                   ", Role ID: " + user.getRoleId());
            } else {
                // LOGGING: Ghi log nếu không tìm thấy user
                System.out.println("[AdminUserDAO] User NOT found with username: " + username);
            }
        } catch (SQLException e) {
            System.err.println("[AdminUserDAO] SQL Error finding user by username '" + username + "': " + e.getMessage());
            e.printStackTrace(); // In stack trace để debug lỗi SQL
        } catch (Exception e) {
            System.err.println("[AdminUserDAO] General Error finding user by username '" + username + "': " + e.getMessage());
            e.printStackTrace(); // In stack trace để debug lỗi khác
        }
        return user;
    }

    public boolean addUser(AdminUser user) {
        // LOGGING: Ghi log khi bắt đầu thêm user
        System.out.println("[AdminUserDAO] Attempting to add user: " + user.getUsername() +
                           ", Hashed Password: " + user.getPasswordHash());

        String sql = "INSERT INTO adminusers (username, password_hash, email, full_name, role_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPasswordHash());
            pstmt.setString(3, user.getEmail());
            pstmt.setString(4, user.getFullName());
            pstmt.setInt(5, user.getRoleId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("[AdminUserDAO] User '" + user.getUsername() + "' added successfully.");
                return true;
            } else {
                System.err.println("[AdminUserDAO] Failed to add user '" + user.getUsername() + "' (no rows affected).");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("[AdminUserDAO] SQL Error adding user '" + user.getUsername() + "': " + e.getMessage());
            // e.printStackTrace(); // Không nên printStackTrace ở DAO nếu Service sẽ xử lý
            // Nếu username là UNIQUE và bạn cố insert trùng, đây sẽ là nơi báo lỗi
            return false;
        }
    }

    // Các phương thức khác (updatePassword, updateUsername, getAllAdminUsers, v.v. nếu có) giữ nguyên
    // Chỉ cần đảm bảo chúng có log tương tự nếu bạn muốn theo dõi hoạt động.
    public boolean updatePassword(int userId, String newPasswordHash) {
        System.out.println("[AdminUserDAO] Attempting to update password for user ID: " + userId + " with new hash: " + newPasswordHash.substring(0, Math.min(10, newPasswordHash.length())) + "...");
        String sql = "UPDATE adminusers SET password_hash = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newPasswordHash);
            pstmt.setInt(2, userId);
            int affectedRows = pstmt.executeUpdate();
            System.out.println("[AdminUserDAO] Password update " + (affectedRows > 0 ? "successful" : "failed (no rows affected)") + " for user ID: " + userId);
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("[AdminUserDAO] SQL Error updating password for user ID " + userId + ": " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // Bạn có thể thêm các phương thức khác như getAllUsers, updateUserProfile, etc.
    // và thêm log tương tự nếu muốn.
}