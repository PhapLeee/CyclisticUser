// src/main/java/com/ccyclistic/MainApp.java
package com.ccyclistic; // Package gốc của MainApp JavaFX

// Import AuthService từ package đúng của nó
// Nếu AuthService của bạn nằm trong com.ccyclistic.service, hãy sửa import này
import com.cyclistic.service.AuthService;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class MainApp extends Application {

    private Stage primaryStage;
    private static MainApp instance; 
    
    public MainApp() {
        instance = this;
    }

    public static MainApp getInstance() {
        return instance;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Cyclistic Data Importer - Pháp Sư JavaFX Edition");

        System.out.println("[MainApp-FX] Initializing JavaFX Login Screen...");
        showLoginScreen();
        // Nếu bạn muốn bỏ qua login để phát triển:
        // showMainDashboard();
    }

    public void showLoginScreen() {
        try {
            FXMLLoader loader = new FXMLLoader();
            // ĐƯỜNG DẪN RESOURCE: Giả sử FXML nằm trong src/main/resources/com/ccyclistic/ui/fxml/
            // Nếu package UI của bạn là com.cyclistic.ui, hãy đổi "ccyclistic" thành "cyclistic"
            loader.setLocation(getClass().getResource("/com/ccyclistic/ui/fxml/Login.fxml"));
            if (loader.getLocation() == null) {
                System.err.println("[MainApp-FX] FATAL: Login.fxml not found at specified path. Check resource path.");
                System.err.println("[MainApp-FX] Attempted path: /com/ccyclistic/ui/fxml/Login.fxml");
                // Cân nhắc hiển thị Alert lỗi và thoát
                javafx.application.Platform.exit();
                return;
            }
            Parent loginLayout = loader.load();

            Scene scene = new Scene(loginLayout);

            // ĐƯỜNG DẪN RESOURCE: Giả sử CSS nằm trong src/main/resources/com/ccyclistic/ui/css/
            // Nếu package UI của bạn là com.cyclistic.ui, hãy đổi "ccyclistic" thành "cyclistic"
            String cssPath = "/com/ccyclistic/ui/css/styles.css";
            if (getClass().getResource(cssPath) == null) {
                 System.err.println("[MainApp-FX] WARNING: styles.css not found at specified path. UI might not be styled correctly.");
                 System.err.println("[MainApp-FX] Attempted path: " + cssPath);
            } else {
                scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource(cssPath)).toExternalForm());
            }


            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            System.err.println("[MainApp-FX] FATAL: Could not load Login.fxml or an error occurred during scene setup.");
            e.printStackTrace();
            // Hiển thị Alert lỗi nghiêm trọng và thoát
            // Alert errorAlert = new Alert(Alert.AlertType.ERROR, "Critical error loading UI. Application will exit.");
            // errorAlert.showAndWait();
            // javafx.application.Platform.exit();
        } catch (NullPointerException e) {
            System.err.println("[MainApp-FX] FATAL: NullPointerException during login screen setup. Most likely a resource was not found (FXML/CSS).");
            e.printStackTrace();
        }
    }

    public void showMainDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader();
            // ĐƯỜNG DẪN RESOURCE: Giả sử FXML nằm trong src/main/resources/com/ccyclistic/ui/fxml/
            loader.setLocation(getClass().getResource("/com/ccyclistic/ui/fxml/MainDashboard.fxml"));
             if (loader.getLocation() == null) {
                System.err.println("[MainApp-FX] FATAL: MainDashboard.fxml not found at specified path. Check resource path.");
                System.err.println("[MainApp-FX] Attempted path: /com/ccyclistic/ui/fxml/MainDashboard.fxml");
                return; // Không thể tiếp tục nếu dashboard không tải được
            }
            Parent mainDashboardLayout = loader.load();

            Scene scene = new Scene(mainDashboardLayout, 1200, 800);

            // ĐƯỜNG DẪN RESOURCE: Giả sử CSS nằm trong src/main/resources/com/ccyclistic/ui/css/
            String cssPath = "/com/ccyclistic/ui/css/styles.css";
            if (getClass().getResource(cssPath) == null) {
                 System.err.println("[MainApp-FX] WARNING: styles.css not found. Dashboard might not be styled correctly.");
                 System.err.println("[MainApp-FX] Attempted path: " + cssPath);
            } else {
                scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource(cssPath)).toExternalForm());
            }

            primaryStage.setScene(scene);
            primaryStage.setTitle("Cyclistic Dashboard");
            primaryStage.centerOnScreen();
        } catch (IOException e) {
            System.err.println("[MainApp-FX] ERROR: Could not load MainDashboard.fxml.");
            e.printStackTrace();
        } catch (NullPointerException e) {
            System.err.println("[MainApp-FX] ERROR: NullPointerException during dashboard screen setup. Most likely a resource was not found (FXML/CSS).");
            e.printStackTrace();
        }
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        System.out.println("[MainApp] Application starting (JavaFX mode)...");

        // --- Logic kiểm tra và tạo admin mặc định ---
        // Đảm bảo AuthService và các dependency của nó (DBConnection, DAO) được khởi tạo đúng cách.
        AuthService tempAuthService = null;
        try {
            // Việc khởi tạo AuthService ở đây sẽ ngầm khởi tạo AdminUserDAO bên trong nó.
            // Đảm bảo DBConnection có thể được thiết lập thành công khi AdminUserDAO cố gắng kết nối.
            tempAuthService = new AuthService();
            System.out.println("[MainApp] AuthService instance created for default admin check.");
        } catch (Exception e) {
            System.err.println("[MainApp] CRITICAL: Failed to initialize AuthService for default admin check. Cannot proceed with admin check/creation.");
            e.printStackTrace();
            // Cân nhắc việc không launch() ứng dụng nếu AuthService không khởi tạo được ở bước này.
            // Tuy nhiên, LoginController cũng sẽ thử khởi tạo AuthService, nên có thể vẫn tiếp tục.
            // System.exit(1); // Hoặc return;
        }

        if (tempAuthService != null) {
            // Truy cập trực tiếp adminUserDAO nếu không có getter
            // và giả định adminUserDAO là public hoặc package-private và MainApp cùng package với AuthService
            if (tempAuthService.adminUserDAO != null) {
                try {
                    // Truy cập trực tiếp adminUserDAO
                    if (tempAuthService.adminUserDAO.findByUsername("admin") == null) {
                        System.out.println("[MainApp] Default admin 'admin' not found by DAO. Attempting to create...");
                        // Giả sử role_id 1 là admin
                        boolean created = tempAuthService.registerDefaultAdmin("admin", "admin123", 1);
                        if (created) {
                            System.out.println("[MainApp] Default admin account ('admin'/'admin123') created successfully by AuthService.");
                        } else {
                            System.err.println("[MainApp] Failed to create default admin account via AuthService. Check DAO/Service logs.");
                        }
                    } else {
                        System.out.println("[MainApp] Default admin 'admin' already exists (found by DAO).");
                    }
                } catch (Exception e) {
                    System.err.println("[MainApp] Error during default admin check/creation: " + e.getMessage());
                    e.printStackTrace();
                    // Đây có thể là lỗi kết nối DB hoặc lỗi logic trong DAO/Service
                }
            } else {
                System.err.println("[MainApp] Error: adminUserDAO is null within tempAuthService instance. Cannot check/create default admin.");
            }
        } else {
             System.out.println("[MainApp] tempAuthService was null, skipping default admin check.");
        }
        // --- Kết thúc logic kiểm tra và tạo admin mặc định ---

        System.out.println("[MainApp] Launching JavaFX application UI...");
        launch(args); // Lệnh này sẽ gọi phương thức start() của Application
    }
}